# LendLoop

**Borrow what you need. Lend what you don’t.**

A neighborhood tool-lending board built for Fluence’s take-home assignment. This is newly created exercise source code, not a claim about a previously deployed product or Allen’s prior engineering experience. AI assistance was used in implementation, testing and documentation; see [AUTHORSHIP.md](AUTHORSHIP.md).

## What is implemented

- Next.js App Router and TypeScript; Clerk authentication; Convex database, reactive queries, validated mutations and HTTP actions.
- Public catalog returns **only tool names and categories**, with no owner names, identities, descriptions, addresses or contact details.
- Signed-in catalog, category filter, condition/description, availability, own listings and edit/remove controls, date-range requests, incoming approvals/declines, borrower cancellation and participant returns.
- Convex enforces ownership and the state machine. Admins can inspect all loans, remove any listing and mark a lender trusted. A client cannot supply its role, owner or borrower identity.
- Date/overlap validation and duplicate-request protection are transactional. Removed listings disappear publicly; pending requests are declined and active loan history survives.
- Transactional notification outbox, sender leases, five bounded retries and five-minute crash recovery. An HTTP 200 does not count as delivery: a durable signed acknowledgment is required.
- n8n request-notification, daily overdue-reminder and error workflows, exported in [n8n/workflows](n8n/workflows).
- Bidirectional HMAC authentication, bounded raw bodies, timestamp validation and idempotent daily reminder/notification writes. Recent automation activity appears on each loan.

**Notification mode is deliberately a logged mock**, expressly allowed by the exercise. No email or SMS provider is configured. A durable “mock notification logged” record is not a message sent to a person. Console logs are at least once; unique Convex activity keys prevent duplicate durable records. External exactly-once notification delivery is not claimed.

## Run locally

Prerequisites: Node.js 24 LTS, npm, a Clerk development application, a Convex development deployment and Docker Compose for n8n. Dependencies and the lockfile are pinned in this repository. Do not use production applicant, healthcare or neighbor data for evaluation.

```sh
npm ci
cp .env.example .env.local
```

1. In Clerk, create a development application and enable a sign-in method. Create/configure the **Convex JWT template**, with audience/application ID `convex`. Copy its issuer domain and development publishable/secret keys using the provider dashboards. No passwords, keys or service accounts are included here.
2. Set `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY` and `NEXT_PUBLIC_CONVEX_URL` in `.env.local`.
3. Configure Convex’s server environment:

   ```sh
   npx convex dev
   npx convex env set CLERK_JWT_ISSUER_DOMAIN https://YOUR-CLERK-ISSUER
   npx convex env set ADMIN_USER_IDS YOUR_ADMIN_CLERK_USER_ID
   ```

   Set `ADMIN_USER_IDS` **before that user’s first sign-in**; profiles are created lazily and no client can promote itself. Existing profile-role changes must be made by an operator through an audited server-side migration, not by editing a browser token. Do not reuse a production admin identity for a public exercise.
4. Run `npm run dev`, then open `http://localhost:3000`.
5. Sign in as two development users to exercise lending/borrowing, plus the allowlisted admin. Clerk verifies credentials; Convex verifies the Clerk JWT independently.
6. Complete [n8n’s setup](n8n/README.md): set a new shared secret of at least 32 characters **only in server environment/credentials**, import all three inactive exports, link the error workflow, verify fixture handling, and then activate the two main workflows.

Do not paste secrets into shell commands that will be saved in shared logs. The dashboards or a secure environment-file/secret-manager workflow are appropriate. `.env*`, build output, dependencies and local validation reports are git-ignored.

The unconfigured app renders its real public shell and a truthful “live catalog isn’t connected” state. It does **not** fabricate available tools, successful sign-ins or delivery. A credentials-free build passing is not a Clerk/Convex integration test.

### Automation environment

| Variable | Where | Purpose |
| --- | --- | --- |
| `CLERK_JWT_ISSUER_DOMAIN` | Convex | Trusted Clerk token issuer; `applicationID: convex` is fixed in `convex/auth.config.ts`. |
| `ADMIN_USER_IDS` | Convex only | Explicit Clerk user IDs allowed an admin profile on initial creation; no public role setter. |
| `AUTOMATION_SHARED_SECRET` | Convex + n8n only | Same random secret, at least 32 characters. Never `NEXT_PUBLIC_*`. |
| `N8N_REQUEST_WEBHOOK_URL` | Convex only | Activated n8n production webhook URL for `request-notification`. HTTPS required. Redirects are rejected. |
| `CONVEX_SITE_URL` | n8n only | Convex HTTP origin, e.g. `https://YOUR-DEPLOYMENT.convex.site`. |
| `ALLOW_LOCAL_AUTOMATION` | Convex | Default false. Explicit local-only HTTP exception for localhost/127.0.0.1/host.docker.internal during controlled development. |
| `N8N_ENCRYPTION_KEY` | n8n only | Persistent encryption key, supplied by the operator; never committed. |

A hosted Convex deployment **cannot reach a laptop’s loopback address**. Use a controlled HTTPS development endpoint/tunnel or a reachable n8n host, with the secret and signature checks intact. This source does not provision a tunnel or expose the local n8n editor. Do not disable authentication or signatures to make connectivity appear successful.

## Architecture

```text
Browser ── Clerk sign-in/JWT ──> Convex public functions
   │                               │
   └── Next.js UI                  ├── profiles / tools / loans
                                   ├── activity (idempotent keys)
                                   └── outbox + transactional scheduler
                                              │ signed raw JSON, event ID
                                              v
                                         n8n webhook
                                              │ mock log; signed acknowledgment
                                              v
                                   Convex /automation/ack

n8n daily schedule ── signed POST /automation/overdue
                  └─ mock log ── signed POST /automation/reminders
```

`convex/model.ts` derives typed function builders directly from the real schema. `src/lib/api.ts` and `convex/refs.ts` use the SDK’s explicit function references. There is no fabricated `_generated` production API. `convex-test` receives an inert test-only module-root anchor because its harness expects a `_generated` path; this grants no production functionality.

### Data and authorization

- Clerk subject is the only authoritative user ID. `actor()` reads verified identity and a server-owned profile. No mutation accepts `ownerId`, `borrowerId` or a caller-selected role.
- Public catalog projection is explicitly `{name, category}`. Authenticated users see lender display names but no addresses, emails or phones. Users’ loan views are queried through ownership/borrowing indexes. Only admins can request `scope: all`.
- New tool text has server-side bounds and category/condition allowlists. Dates are validated as real ISO dates; ranges are inclusive, cannot start in the past and cannot exceed one year.
- Approval rechecks overlapping approved loans in the same transaction. Only the lender decides. Only an involved lender/borrower can mark a started, approved loan returned. Admin visibility does not grant that unrelated action.
- Tool deletion is a reversible-in-database retirement marker, not erasure of active loan/audit records. Pending requests are declined with notifications; an approved loan remains actionable even after its listing is retired.
- The app does not collect or log lending addresses, phone numbers, financial data, medical data or full Clerk tokens. Tool descriptions remind users not to enter contact information.

### Integration and recovery

- Header `x-lendloop-timestamp`: Unix seconds. `x-lendloop-signature`: lowercase hex HMAC-SHA256 over **`timestamp + "." + exact raw body`**. The receiving side rejects missing/bad signatures, bodies above 16 KiB and timestamps more than five minutes old or ahead. JSON is parsed only after authentication.
- Convex writes a stable outbox event in the loan mutation’s transaction, then schedules delivery. The n8n payload contains version, event/loan IDs, kind, tool name, opaque recipient ID, status and creation time—no full user profile or credentials.
- A 15-second lease limits concurrent senders. HTTP requests have an eight-second deadline; a failed attempt backs off 5/10/20/40 seconds up to five attempts. A five-minute Convex cron recovers pending or expired leases after interruption, with bounded batches. Exhaustion creates an explicit operator-review activity record.
- Acknowledgments use `event:<eventId>` as the unique transaction key; reminders use `reminder:<loanId>:<UTC-day>`. Retrying the same signed callback returns `{ok:true,duplicate:true}` without adding a second activity record.
- A callback failure after logging may repeat an n8n console line. It cannot establish real email delivery. The notification adapter would need provider-level idempotency before enabling an external transport.
- Overdue queries return only loan ID, tool name, borrower ID, due date and daily reminder key. Returned/cancelled/declined/pending loans are excluded. Successfully recorded daily reminders disappear from subsequent batches. The exercise has an explicit 1,000-overdue-loan safety cap; exceeding it fails visibly rather than silently omitting loans. n8n also bounds batch progression.
- The HTTP endpoints are server-to-server only. They do not allow cross-origin browser reads or expose a public unauthenticated overdue feed. Errors return sanitized codes, without request bodies, secrets or provider response text.

## Validation

```sh
npm run typecheck
npm test
npm run test:n8n
npm run build
```

Tests call the **actual Convex schema/functions and HTTP router** through the official `convex-test` harness, not a parallel in-memory reimplementation. They cover anonymous/foreign-user denial, server-role administration, public data projection, duplicate requests, overlapping approvals, retirement/history, participant returns, outbox writes/leases/recovery, HMAC tampering, durable callback replay and daily reminder exclusion. Controlled scheduled functions use fake timers; no employer or notification recipient is contacted. Native n8n tests execute the actual exported Code-node bodies and a local signed-wire fixture.

See [VALIDATION.md](VALIDATION.md) for the observed command results and live checks that remain. In particular: provider login, deployed Convex execution, actual n8n engine import/run, real restart/crash recovery and human visual review have **not** been established by unit tests or a successful build.

## Before production

Keep this a development exercise until the hosted Clerk/Convex/n8n path and two-user permissions are validated. Then add audited role administration, cursor pagination instead of the exercise’s 200-listing/loan view caps, paginated outbox/reminder workers, rate limits/abuse controls, retention/deletion policy, monitoring/alert destinations, separate environments and rotating secrets, CSP tuned to Clerk/Convex, and provider-idempotent notification delivery. Test time-boundary changes, concurrent approvals, restart recovery and inaccessible third-party services on a staging deployment. A contact-exchange/handoff design requires an explicit privacy decision; no physical address collection is added here.

## Provider documentation used

- [Clerk Next.js quickstart](https://clerk.com/docs/nextjs/getting-started/quickstart)
- [Convex + Clerk](https://docs.convex.dev/auth/clerk)
- [Convex HTTP actions](https://docs.convex.dev/functions/http-actions)
- [Convex action/scheduler behavior](https://docs.convex.dev/functions/actions)
- [n8n integration documentation and raw-body details](n8n/README.md)
