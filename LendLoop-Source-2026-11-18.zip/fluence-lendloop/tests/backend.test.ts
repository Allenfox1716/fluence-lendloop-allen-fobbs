import { beforeEach, afterEach, describe, expect, it, vi } from "vitest";
import { convexTest } from "convex-test";
import schema from "../convex/schema";
import { api } from "../src/lib/api";
import { refs } from "../convex/refs";
import { todayUTC } from "../src/domain/rules";
import { signBody } from "../src/domain/signatures";
// convex-test discovers its module root using a _generated path. This inert
// test-only anchor supplies that root; production uses schema-derived wrappers.
const modules = { ...import.meta.glob("../convex/**/*.ts"), "../convex/_generated/testAnchor.ts": async () => ({}) };
const secret = "fixture-only-not-a-deployment-secret-123456";
function setup() {
  const t = convexTest(schema, modules);
  return { t, alice: t.withIdentity({ subject: "alice", name: "Alice" }), bob: t.withIdentity({ subject: "bob", name: "Bob" }), eve: t.withIdentity({ subject: "eve", name: "Eve" }), admin: t.withIdentity({ subject: "admin", name: "Admin" }) };
}
const listing = { name: "Drill", category: "Power tools" as const, condition: "Good" as const, description: "Cordless drill with charger." };
async function signedFetch(t: ReturnType<typeof setup>["t"], path: string, payload: unknown) {
  const raw = JSON.stringify(payload);const timestamp = Math.floor(Date.now() / 1000).toString();
  return t.fetch(path, { method: "POST", headers: { "content-type": "application/json", "x-lendloop-timestamp": timestamp, "x-lendloop-signature": await signBody(secret, timestamp, raw) }, body: raw });
}
beforeEach(() => { vi.useFakeTimers();vi.stubEnv("ADMIN_USER_IDS", "admin");vi.stubEnv("AUTOMATION_SHARED_SECRET", secret); });
afterEach(() => { vi.useRealTimers();vi.unstubAllEnvs();vi.unstubAllGlobals(); });
describe("Convex authorization and lifecycle", () => {
  it("requires authentication and exposes only name/category publicly", async () => {
    const { t, alice } = setup();
    await expect(t.mutation(api.tools.create, listing)).rejects.toThrow("Sign in");
    await expect(t.query(api.loans.list, { scope: "mine" })).rejects.toThrow("Sign in");
    await alice.mutation(api.users.ensure, {});await alice.mutation(api.tools.create, listing);
    expect(await t.query(api.tools.publicList, {})).toEqual([{ name: "Drill", category: "Power tools" }]);
  });
  it("takes ownership from verified identity and refuses another user's edit/delete", async () => {
    const { alice, bob } = setup();await alice.mutation(api.users.ensure, {});
    const toolId = await alice.mutation(api.tools.create, listing);
    await expect(bob.mutation(api.tools.edit, { ...listing, toolId, name: "Hijacked" })).rejects.toThrow("own listings");
    await expect(bob.mutation(api.tools.remove, { toolId })).rejects.toThrow("own listings");
    await alice.mutation(api.tools.edit, { ...listing, toolId, name: "Updated drill" });
    expect((await alice.query(api.tools.list, {}))[0].name).toBe("Updated drill");
  });
  it("allows only server-bootstrapped admins to trust lenders, inspect all loans and remove any listing", async () => {
    const { alice, bob, admin } = setup();await alice.mutation(api.users.ensure, {});await admin.mutation(api.users.ensure, {});
    const toolId = await alice.mutation(api.tools.create, listing);
    await expect(bob.mutation(api.users.setTrusted, { toolId, trusted: true })).rejects.toThrow("Administrator");
    await expect(bob.query(api.loans.list, { scope: "all" })).rejects.toThrow("Administrator");
    await admin.mutation(api.users.setTrusted, { toolId, trusted: true });
    expect((await alice.query(api.tools.list, {}))[0].trusted).toBe(true);
    await admin.mutation(api.tools.remove, { toolId });
    expect((await alice.query(api.tools.list, {}))[0].removed).toBe(true);
  });
  it("rejects unsupported categories and self-borrowing", async () => {
    const { alice } = setup();await alice.mutation(api.users.ensure, {});
    await expect(alice.mutation(api.tools.create, { ...listing, category: "Unvalidated" as never })).rejects.toThrow("supported category");
    const toolId = await alice.mutation(api.tools.create, listing);
    await expect(alice.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() })).rejects.toThrow("own tool");
  });
  it("commits a stable outbox event with a request and protects decisions from non-owners", async () => {
    const { t, alice, bob, eve } = setup();await alice.mutation(api.users.ensure, {});await bob.mutation(api.users.ensure, {});
    const toolId = await alice.mutation(api.tools.create, listing);
    const loanId = await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });
    const events = await t.run(ctx => ctx.db.query("outbox").collect());
    expect(events).toHaveLength(1);expect(events[0]).toMatchObject({ loanId, kind: "request.created", recipientUserId: "alice", state: "pending" });
    await expect(eve.mutation(api.loans.decide, { loanId, decision: "approved" })).rejects.toThrow("own listings");
    expect(await eve.query(api.loans.list, { scope: "mine" })).toEqual([]);
  });
  it("prevents exact duplicate pending requests and overlapping approvals", async () => {
    const { alice, bob, eve } = setup();await alice.mutation(api.users.ensure, {});
    const toolId = await alice.mutation(api.tools.create, listing);const dates = { startDate: "2099-01-01", endDate: "2099-01-05" };
    const first = await bob.mutation(api.loans.request, { toolId, ...dates });
    await expect(bob.mutation(api.loans.request, { toolId, ...dates })).rejects.toThrow("already exists");
    const second = await eve.mutation(api.loans.request, { toolId, startDate: "2099-01-04", endDate: "2099-01-07" });
    await alice.mutation(api.loans.decide, { loanId: first, decision: "approved" });
    await expect(alice.mutation(api.loans.decide, { loanId: second, decision: "approved" })).rejects.toThrow("overlaps");
    await expect(eve.mutation(api.loans.request, { toolId, ...dates })).rejects.toThrow("overlaps");
  });
  it("declines pending requests when listing removed while retaining approved loan history", async () => {
    const { alice, bob, eve } = setup();await alice.mutation(api.users.ensure, {});
    const toolId = await alice.mutation(api.tools.create, listing);
    const approved = await bob.mutation(api.loans.request, { toolId, startDate: "2099-01-01", endDate: "2099-01-03" });
    await alice.mutation(api.loans.decide, { loanId: approved, decision: "approved" });
    await eve.mutation(api.loans.request, { toolId, startDate: "2099-02-01", endDate: "2099-02-02" });
    await alice.mutation(api.tools.remove, { toolId });
    expect((await alice.query(api.loans.list, { scope: "incoming" })).map(l => l.status).sort()).toEqual(["approved", "declined"]);
    await expect(bob.mutation(api.loans.request, { toolId, startDate: "2099-03-01", endDate: "2099-03-02" })).rejects.toThrow("no longer available");
  });
  it("lets only a participant return an approved started loan and restores availability", async () => {
    const { t, alice, bob, eve } = setup();await alice.mutation(api.users.ensure, {});
    const toolId = await alice.mutation(api.tools.create, listing);const day = todayUTC();
    const loanId = await bob.mutation(api.loans.request, { toolId, startDate: day, endDate: day });
    await alice.mutation(api.loans.decide, { loanId, decision: "approved" });expect(await t.query(api.tools.publicList, {})).toEqual([]);
    await expect(eve.mutation(api.loans.markReturned, { loanId })).rejects.toThrow("Only this lender");
    await bob.mutation(api.loans.markReturned, { loanId });expect(await t.query(api.tools.publicList, {})).toHaveLength(1);
    await expect(bob.mutation(api.loans.markReturned, { loanId })).rejects.toThrow("Only an approved");
  });
  it("only lets the borrower cancel their pending request", async () => {
    const { alice, bob, eve } = setup();await alice.mutation(api.users.ensure, {});
    const toolId = await alice.mutation(api.tools.create, listing);const loanId = await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });
    await expect(eve.mutation(api.loans.cancel, { loanId })).rejects.toThrow("Only your pending");await bob.mutation(api.loans.cancel, { loanId });
    expect((await bob.query(api.loans.list, { scope: "mine" }))[0].status).toBe("cancelled");
  });
});
describe("real Convex HTTP and persistence connections", () => {
  it("rejects unauthenticated, altered, malformed and unsupported signed payloads", async () => {
    const { t } = setup();
    expect((await t.fetch("/automation/overdue", { method: "POST", body: "{}" })).status).toBe(401);
    const body = JSON.stringify({ version: 1, requestId: "q", limit: 10 });const timestamp = Math.floor(Date.now() / 1000).toString();const signature = await signBody(secret, timestamp, body);
    expect((await t.fetch("/automation/overdue", { method: "POST", headers: { "x-lendloop-timestamp": timestamp, "x-lendloop-signature": signature }, body: body + " " })).status).toBe(401);
    expect((await signedFetch(t, "/automation/overdue", { version: 2, requestId: "q", limit: 10 })).status).toBe(400);
    expect((await signedFetch(t, "/automation/overdue", { version: 1, requestId: "q", limit: 999 })).status).toBe(400);
  });
  it("persists one acceptance record across signed acknowledgment replay", async () => {
    const { t, alice, bob } = setup();await alice.mutation(api.users.ensure, {});const toolId = await alice.mutation(api.tools.create, listing);
    await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });
    const [event] = await t.run(ctx => ctx.db.query("outbox").collect());
    const p = { version: 1, eventId: event._id, outcome: "logged" };
    expect(await (await signedFetch(t, "/automation/ack", p)).json()).toEqual({ ok: true, duplicate: false });
    expect(await (await signedFetch(t, "/automation/ack", p)).json()).toEqual({ ok: true, duplicate: true });
    expect(await t.run(ctx => ctx.db.query("activity").collect())).toHaveLength(1);
    expect((await t.query(refs.event, { eventId: event._id }))?.state).toBe("acknowledged");
    expect((await alice.query(api.loans.list, { scope: "incoming" }))[0].activities[0].outcome).toBe("mock notification logged");
  });
  it("leases a single sender and preserves acknowledgment against delayed failure cleanup", async () => {
    const { t, alice, bob } = setup();await alice.mutation(api.users.ensure, {});const toolId = await alice.mutation(api.tools.create, listing);await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });
    const [e] = await t.run(ctx => ctx.db.query("outbox").collect());
    expect(await t.mutation(refs.beginAttempt, { eventId: e._id })).toBe(1);expect(await t.mutation(refs.beginAttempt, { eventId: e._id })).toBe(0);
    await t.mutation(refs.ack, { eventId: e._id, outcome: "logged" });await t.mutation(refs.failedAttempt, { eventId: e._id, expectedAttempt: 1, exhausted: true });
    expect((await t.query(refs.event, { eventId: e._id }))?.state).toBe("acknowledged");
  });
  it("fetches overdue minimal fields and writes exactly one reminder per loan/UTC day", async () => {
    const { t, alice, bob } = setup();await alice.mutation(api.users.ensure, {});const toolId = await alice.mutation(api.tools.create, listing);const loanId = await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });await alice.mutation(api.loans.decide, { loanId, decision: "approved" });
    await t.run(ctx => ctx.db.patch(loanId, { startDate: "2020-01-01", endDate: "2020-01-02" }));
    const response = await signedFetch(t, "/automation/overdue", { version: 1, requestId: "fixture-query", limit: 50 });expect(response.status).toBe(200);
    const result = await response.json();expect(result.loans).toHaveLength(1);expect(Object.keys(result.loans[0]).sort()).toEqual(["borrowerId", "endDate", "loanId", "reminderKey", "toolName"]);
    const p = { version: 1, loanId, reminderKey: result.loans[0].reminderKey, outcome: "logged" };
    expect(await (await signedFetch(t, "/automation/reminders", p)).json()).toEqual({ ok: true, duplicate: false });
    expect(await (await signedFetch(t, "/automation/reminders", p)).json()).toEqual({ ok: true, duplicate: true });
    expect((await (await signedFetch(t, "/automation/overdue", { version: 1, requestId: "second-query", limit: 50 })).json()).loans).toEqual([]);
    expect(await t.run(ctx => ctx.db.query("activity").collect())).toHaveLength(1);
  });
  it("rejects stale reminder keys or a loan returned before the writeback", async () => {
    const { t, alice, bob } = setup();await alice.mutation(api.users.ensure, {});const toolId = await alice.mutation(api.tools.create, listing);const loanId = await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });await alice.mutation(api.loans.decide, { loanId, decision: "approved" });
    await t.run(ctx => ctx.db.patch(loanId, { startDate: "2020-01-01", endDate: "2020-01-02" }));
    expect((await signedFetch(t, "/automation/reminders", { version: 1, loanId, reminderKey: `${loanId}:2020-01-03`, outcome: "logged" })).status).toBe(409);
    await bob.mutation(api.loans.markReturned, { loanId });
    expect((await signedFetch(t, "/automation/reminders", { version: 1, loanId, reminderKey: `${loanId}:${todayUTC()}`, outcome: "logged" })).status).toBe(409);
  });
  it("fails closed when deployment automation is unconfigured", async () => {
    const { t } = setup();vi.stubEnv("AUTOMATION_SHARED_SECRET", "");expect((await t.fetch("/automation/overdue", { method: "POST", body: "{}" })).status).toBe(503);
  });
  it("does not count a generic webhook HTTP200 as accepted and records exhausted delivery", async () => {
    const { t, alice, bob } = setup();await alice.mutation(api.users.ensure, {});const toolId = await alice.mutation(api.tools.create, listing);await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });
    const [event] = await t.run(ctx => ctx.db.query("outbox").collect());
    await t.run(ctx => ctx.db.patch(event._id, { attempts: 4 }));
    vi.stubEnv("N8N_REQUEST_WEBHOOK_URL", "https://automation.example.test/webhook/request");
    vi.stubGlobal("fetch", vi.fn(async () => new Response("{}", { status: 200 })));
    await t.action(refs.deliver, { eventId: event._id });
    expect((await t.query(refs.event, { eventId: event._id }))?.state).toBe("failed");
    expect((await t.run(ctx => ctx.db.query("activity").collect()))[0].outcome).toContain("operator review");
    expect(await t.run(ctx => ctx.db.query("loans").collect())).toHaveLength(1);
  });
  it("retains durable acceptance when response observation fails after the writeback", async () => {
    const { t, alice, bob } = setup();await alice.mutation(api.users.ensure, {});const toolId = await alice.mutation(api.tools.create, listing);await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });
    const [event] = await t.run(ctx => ctx.db.query("outbox").collect());
    vi.stubEnv("N8N_REQUEST_WEBHOOK_URL", "https://automation.example.test/webhook/request");
    vi.stubGlobal("fetch", vi.fn(async () => { await t.mutation(refs.ack, { eventId: event._id, outcome: "logged" });throw new Error("fixture response timeout"); }));
    await t.action(refs.deliver, { eventId: event._id });
    expect((await t.query(refs.event, { eventId: event._id }))?.state).toBe("acknowledged");
    await t.action(refs.deliver, { eventId: event._id });
    expect(fetch).toHaveBeenCalledTimes(1);
    expect(await t.run(ctx => ctx.db.query("activity").collect())).toHaveLength(1);
  });
  it("recovers expired sender leases and exposes exhausted crashes without duplicating acceptance", async () => {
    const { t, alice, bob } = setup();await alice.mutation(api.users.ensure, {});const toolId = await alice.mutation(api.tools.create, listing);await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });
    const [event] = await t.run(ctx => ctx.db.query("outbox").collect());
    await t.run(ctx => ctx.db.patch(event._id, { state: "sending", attempts: 2, leaseUntil: Date.now() - 1000 }));
    expect(await t.mutation(refs.recover, {})).toBe(1);expect((await t.query(refs.event, { eventId: event._id }))?.state).toBe("pending");
    await t.run(ctx => ctx.db.patch(event._id, { state: "sending", attempts: 5, leaseUntil: Date.now() - 1000 }));
    expect(await t.mutation(refs.recover, {})).toBe(0);expect((await t.query(refs.event, { eventId: event._id }))?.state).toBe("failed");
    expect(await t.mutation(refs.recover, {})).toBe(0);expect(await t.run(ctx => ctx.db.query("activity").collect())).toHaveLength(1);
  });
  it("fences delayed cleanup from an older sender and never starts a sixth attempt", async () => {
    const { t, alice, bob } = setup();await alice.mutation(api.users.ensure, {});const toolId = await alice.mutation(api.tools.create, listing);await bob.mutation(api.loans.request, { toolId, startDate: todayUTC(), endDate: todayUTC() });
    const [event] = await t.run(ctx => ctx.db.query("outbox").collect());
    await t.run(ctx => ctx.db.patch(event._id, { state: "sending", attempts: 2, leaseUntil: Date.now() + 1000 }));
    expect(await t.mutation(refs.failedAttempt, { eventId: event._id, expectedAttempt: 1, exhausted: false })).toBe(false);
    expect((await t.query(refs.event, { eventId: event._id }))?.state).toBe("sending");
    await t.run(ctx => ctx.db.patch(event._id, { attempts: 5, leaseUntil: Date.now() - 1000 }));
    expect(await t.mutation(refs.beginAttempt, { eventId: event._id })).toBe(0);
    expect((await t.query(refs.event, { eventId: event._id }))?.attempts).toBe(5);
  });
});
