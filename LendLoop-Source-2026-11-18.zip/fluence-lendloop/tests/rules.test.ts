import { describe, it, expect } from "vitest";
import { validateRange, validDate, overlaps, boundedText } from "../src/domain/rules";
import { signBody, verifySignedBody } from "../src/domain/signatures";
describe("date and text invariants", () => {
  it("rejects impossible dates and reversed/past/oversized ranges", () => {
    expect(validDate("2026-02-30")).toBe(false);
    expect(validDate("2028-02-29")).toBe(true);
    for (const [a, b] of [["2026-02-30", "2026-03-02"], ["2026-02-04", "2026-02-03"], ["2025-12-31", "2026-01-04"], ["2026-01-01", "2027-01-03"]]) expect(() => validateRange(a, b, "2026-01-01")).toThrow();
  });
  it("treats dates as inclusive and trims/bounds listing text", () => {
    expect(overlaps("2026-01-01", "2026-01-03", "2026-01-03", "2026-01-06")).toBe(true);
    expect(overlaps("2026-01-01", "2026-01-02", "2026-01-03", "2026-01-06")).toBe(false);
    expect(boundedText(" Drill ", "Name", 10)).toBe("Drill");
    expect(() => boundedText(" ", "Name", 10)).toThrow();
    expect(() => boundedText("long", "Name", 3)).toThrow();
  });
});
describe("automation raw-body authentication", () => {
  const secret = "fixture-only-not-a-deployment-secret-123456";
  const now = Date.parse("2026-11-18T12:00:00Z");const stamp = Math.floor(now / 1000).toString();
  it("accepts exact signed bytes and rejects whitespace/body/header tampering", async () => {
    const body = '{"version":1}';const sig = await signBody(secret, stamp, body);
    expect(await verifySignedBody(secret, stamp, sig, body, now)).toBe(true);
    expect(await verifySignedBody(secret, stamp, sig, '{ "version":1}', now)).toBe(false);
    expect(await verifySignedBody(secret, stamp, "f".repeat(64), body, now)).toBe(false);
    expect(await verifySignedBody(secret, null, sig, body, now)).toBe(false);
  });
  it("rejects stale/future timestamps, oversized bodies and unconfigured secrets", async () => {
    const sig = await signBody(secret, stamp, "{}");
    expect(await verifySignedBody(secret, stamp, sig, "{}", now + 301000)).toBe(false);
    expect(await verifySignedBody(secret, stamp, sig, "{}", now - 301000)).toBe(false);
    expect(await verifySignedBody(secret, stamp, sig, "x".repeat(16385), now)).toBe(false);
    await expect(signBody("short", stamp, "{}")).rejects.toThrow();
  });
});
