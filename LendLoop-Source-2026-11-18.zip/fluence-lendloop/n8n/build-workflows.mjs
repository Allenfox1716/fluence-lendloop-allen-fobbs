// LendLoop isolated exercise source.
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
const root = dirname(fileURLToPath(import.meta.url));
const shared = readFileSync(join(root, 'code/shared.js'), 'utf8');
const code = (name) => (name === 'sanitized-error' ? '' : shared + '\n') + readFileSync(join(root, `code/${name}.js`), 'utf8');
const node = (id, name, type, typeVersion, position, parameters, more = {}) => ({ id, name, type: `n8n-nodes-base.${type}`, typeVersion, position, parameters, ...more });
const codeNode = (id, name, position, source) => node(id, name, 'code', 2, position, { mode: 'runOnceForAllItems', jsCode: code(source) });
const link = (name, index = 0) => ({ node: name, type: 'main', index });
const http = (id, name, position) => node(id, name, 'httpRequest', 4.2, position, {
  method: 'POST', url: '={{ $json.url }}', sendHeaders: true,
  headerParameters: { parameters: [
    { name: 'content-type', value: 'application/json' },
    { name: 'x-lendloop-timestamp', value: '={{ $json.timestamp }}' },
    { name: 'x-lendloop-signature', value: '={{ $json.signature }}' },
  ] },
  sendBody: true, contentType: 'raw', rawContentType: 'application/json', body: '={{ $json.rawBody }}',
  options: { timeout: 10000, response: { response: { responseFormat: 'json' } } },
}, { retryOnFail: true, maxTries: 3, waitBetweenTries: 1000 });
const settings = { executionOrder: 'v1', timezone: 'UTC', executionTimeout: 120, saveDataSuccessExecution: 'none', saveDataErrorExecution: 'all', saveManualExecutions: false };
const truth = (id, name, position, left, operation, value) => node(id, name, 'if', 2.2, position, { conditions: { options: { caseSensitive: true, leftValue: '', typeValidation: 'strict', version: 2 }, conditions: [{ id: `${id}-condition`, leftValue: left, rightValue: value, operator: { type: operation === 'gt' ? 'number' : 'boolean', operation, singleValue: operation === 'true' } }], combinator: 'and' }, options: {} });

const errors = {
  id: 'lendloopErrors01', name: 'LendLoop — sanitized automation errors', active: false, nodes: [
    node('errors-trigger', 'Automation error', 'errorTrigger', 1, [0, 0], {}),
    codeNode('errors-log', 'Record sanitized error', [240, 0], 'sanitized-error'),
  ], connections: { 'Automation error': { main: [[link('Record sanitized error')]] } }, settings,
};
const request = {
  id: 'lendloopRequest1', name: 'LendLoop — request notification (logged mock)', active: false,
  nodes: [
    node('request-webhook', 'Signed request event', 'webhook', 2.1, [0, 0], { httpMethod: 'POST', path: 'lendloop/requests', responseMode: 'responseNode', options: { rawBody: true } }, { webhookId: 'lendloop-requests-v1' }),
    codeNode('request-verify', 'Verify signed event', [240, 0], 'verify-event'),
    codeNode('request-log', 'Log notification and sign acknowledgement', [500, 0], 'log-request-and-sign-ack'),
    http('request-ack', 'Persist notification acknowledgement', [780, 0]),
    codeNode('request-confirm', 'Confirm durable acknowledgement', [1040, 0], 'confirm-request-ack'),
    node('request-response', 'Respond after persistence', 'respondToWebhook', 1.4, [1300, 0], { respondWith: 'json', responseBody: '={{ $json }}', options: { responseCode: 200 } }),
  ], connections: {
    'Signed request event': { main: [[link('Verify signed event')]] },
    'Verify signed event': { main: [[link('Log notification and sign acknowledgement')]] },
    'Log notification and sign acknowledgement': { main: [[link('Persist notification acknowledgement')]] },
    'Persist notification acknowledgement': { main: [[link('Confirm durable acknowledgement')]] },
    'Confirm durable acknowledgement': { main: [[link('Respond after persistence')]] },
  }, settings: { ...settings, errorWorkflow: errors.id },
};
const overdue = {
  id: 'lendloopOverdue1', name: 'LendLoop — daily overdue reminders (logged mock)', active: false,
  nodes: [
    node('overdue-schedule', 'Daily at 09 UTC', 'scheduleTrigger', 1.2, [0, 0], { rule: { interval: [{ field: 'cronExpression', expression: '0 9 * * *' }] } }),
    node('overdue-manual', 'Manual controlled run', 'manualTrigger', 1, [0, 180], {}),
    codeNode('overdue-sign', 'Sign overdue query', [250, 0], 'sign-overdue-query'),
    http('overdue-fetch', 'Fetch overdue loans', [500, 0]),
    codeNode('overdue-validate', 'Validate overdue batch', [750, 0], 'validate-overdue-batch'),
    truth('overdue-has', 'Has overdue loans?', [1000, 0], '={{ $json.count }}', 'gt', 0),
    codeNode('overdue-log', 'Log reminders and sign write-backs', [1250, -100], 'log-reminders-and-sign'),
    http('overdue-write', 'Persist reminder results', [1500, -100]),
    codeNode('overdue-advance', 'Confirm results and advance batch', [1750, -100], 'advance-batch'),
    truth('overdue-more', 'More overdue loans?', [2000, -100], '={{ $json.more }}', 'true', true),
    node('overdue-finish', 'Finished bounded reminder run', 'noOp', 1, [2250, 100], {}),
  ], connections: {
    'Daily at 09 UTC': { main: [[link('Sign overdue query')]] },
    'Manual controlled run': { main: [[link('Sign overdue query')]] },
    'Sign overdue query': { main: [[link('Fetch overdue loans')]] },
    'Fetch overdue loans': { main: [[link('Validate overdue batch')]] },
    'Validate overdue batch': { main: [[link('Has overdue loans?')]] },
    'Has overdue loans?': { main: [[link('Log reminders and sign write-backs')], [link('Finished bounded reminder run')]] },
    'Log reminders and sign write-backs': { main: [[link('Persist reminder results')]] },
    'Persist reminder results': { main: [[link('Confirm results and advance batch')]] },
    'Confirm results and advance batch': { main: [[link('More overdue loans?')]] },
    'More overdue loans?': { main: [[link('Sign overdue query')], [link('Finished bounded reminder run')]] },
  }, settings: { ...settings, executionTimeout: 1200, errorWorkflow: errors.id },
};
for (const [name, workflow] of [['errors', errors], ['request-notification', request], ['overdue-reminders', overdue]]) {
  writeFileSync(join(root, `workflows/${name}.json`), JSON.stringify(workflow, null, 2) + '\n');
}
console.log('Built three inactive n8n workflow exports; no secrets or external execution.');
