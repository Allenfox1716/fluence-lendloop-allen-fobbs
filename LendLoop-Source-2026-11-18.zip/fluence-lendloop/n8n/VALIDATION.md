# Automation validation record

Validated locally on November 18, 2026, with Node.js v24.22.1.

- `node n8n/build-workflows.mjs`: passed; generated three inactive JSON exports.
- `node --test n8n/test/workflows.test.mjs`: **17 tests passed, 0 failed**.
- The tests execute the actual Code-node source bodies, validate all exported node connections and error-workflow references, and exercise raw-byte signing/verification, expiry, malformed-event rejection, minimization, durable-ack gating, daily keys, duplicate rejection and bounded batch progress.
- The local HTTP fixture received the exact signed raw JSON. Replaying its event ID produced one durable fixture record and a duplicate acknowledgement. This fixture does not replace the actual Convex backend tests.
- `node --check n8n/smoke.mjs`: passed. The smoke script has not sent a request to a deployed provider.
- Docker Compose YAML parsed successfully with Ruby's YAML parser. This verifies YAML syntax, not Docker's full Compose schema or a running container.

The host does not have a Docker CLI. No n8n container was started, no workflow was imported or published in a live n8n engine, no scheduler was activated, and no deployed Convex/n8n roundtrip or crash/restart test was performed here. No email/SMS/Slack delivery exists: the exercise uses explicit logged-mock notifications and durable Convex activity acknowledgements.

The controlled integration checks still needed are detailed in `n8n/README.md`: pinned-engine import, actual raw-binary webhook behavior, test-event acknowledgement in Convex and UI, same-day reminder replay, error workflow activation, restart recovery and the deployed-network configuration.
