# LendLoop automation

The notification channel in this exercise is intentionally **logged mock**. It writes a minimized structured line to the n8n execution console and persists the result back to Convex. No email, SMS, or Slack message is sent. The app should show “logged mock”, not “delivered”, for this activity.

## Local setup

1. Install Docker with Compose. Use the pinned `docker.n8n.io/n8nio/n8n:2.48.5` image in the repository; it was the official stable release checked for this exercise. Review current security releases before a production deployment.
2. Copy `n8n/.env.example` to a private, git-ignored `.env.n8n` in the project root. Set `CONVEX_SITE_URL` to the HTTP-action origin (`.convex.site`, not `.convex.cloud`). Set `AUTOMATION_SHARED_SECRET` to an independently generated random secret of at least 32 characters, and set the same value on the Convex test deployment. Set a separate random, persistent `N8N_ENCRYPTION_KEY`; never rotate it casually or reuse the HMAC secret as this key. Keep both out of workflow JSON, screenshots and logs. Set file permissions to 0600.
3. Run `docker compose --env-file .env.n8n up -d`. The editor is bound to `127.0.0.1:5678` only. Complete n8n owner-account setup in the local editor. Compose uses HTTP and non-secure cookies only for this loopback-only exercise. Do not expose this configuration to a LAN or Internet.
4. Import `n8n/workflows/errors.json`, then `request-notification.json` and `overdue-reminders.json`. The JSON exports are intentionally inactive. Import through the editor or the official CLI, for example `docker compose --env-file .env.n8n exec n8n n8n import:workflow --input=/workflows/errors.json`. Repeat for the other two files.
5. Open the imported error workflow, review it and publish it. Open both main workflows and verify that **Settings → Error workflow** points to that imported error workflow. The exports link the stable repository ID `lendloopErrors01`; if your import assigns new IDs, select the actual imported workflow rather than leaving a stale reference.
6. For a development run, select **Listen for test event** on the request webhook. Use its displayed `/webhook-test/lendloop/requests` URL as the Convex test deployment's request-notification target. For ongoing execution publish the workflow and use the displayed `/webhook/lendloop/requests` production URL. A managed Convex deployment cannot reach `localhost`: use a separately secured development tunnel or hosted test n8n instance when testing that connection. This repository does not create a tunnel or publish any service.
7. Run a controlled loan request through the app. Verify the same event ID in the Convex outbox, n8n execution, successful acknowledgement and app automation activity. For daily reminders, create a controlled approved overdue loan, then manually run the reminder workflow and verify one persisted reminder key for that UTC day. Run it again: the same day must not create a second durable reminder. Only then enable the daily schedule.

The intentionally enabled `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` lets the Code nodes sign messages using the environment secret. Only trusted instance owners may edit workflows; any such editor can execute code and read that secret. `NODE_FUNCTION_ALLOW_BUILTIN=crypto` permits only the required built-in module. No community nodes or Python execution are required. The Compose deployment is an exercise configuration, not a multi-tenant automation service.

## The workflows

### Request notification

`Signed request event → Verify signed event → Log notification and sign acknowledgement → Persist notification acknowledgement → Confirm durable acknowledgement → Respond after persistence`

The Webhook node has **Raw Body** enabled. Verification uses n8n's documented `this.helpers.getBinaryDataBuffer(0, 'data')`, so the HMAC covers the bytes received—not a JSON object reserialized with different whitespace or key order. Malformed signatures, expired timestamps, payloads above 16 KiB and unrecognized event versions/kinds/statuses fail before logging. Only the fields needed for the notification survive validation. A webhook200 is returned only after Convex confirms `{ok:true,duplicate:boolean}`.

### Daily overdue reminders

The schedule is daily at 09:00 UTC. A manual trigger supports controlled testing. Each signed query requests at most 50 loans. The workflow validates the response, logs each mock reminder, and posts a signed result using the stable key `${loanId}:${todayUTC}`. It loops only after every result in the batch has a confirmed durable acknowledgement. The Convex endpoint must omit loans whose same-day reminder key is already recorded. It stops after 20 batches and fails visibly if a backlog remains; malformed responses or `more:true` with an empty page also fail rather than loop forever.

`requestId` identifies an individual read page. Reminder idempotency is based on the backend's stable daily reminder key, not the n8n execution ID. A UTC day rollover during an in-flight batch may reject a previous-day key; inspect the failed execution and rerun against the new day rather than changing its meaning silently.

### Errors and retries

HTTP nodes have a 10 second deadline and up to 3 attempts, one second apart. All writes are idempotent at Convex. Nodes do not “continue on fail”; unsuccessful acknowledgements stop the workflow. The separate Error Trigger workflow records operational identifiers (workflow ID, execution ID, failed node, timestamp) without copying raw payloads, arbitrary error text, stacks or secrets. Review failed executions in the access-controlled editor. The error workflow deliberately makes no further network request, avoiding a failed alert service hiding the original failure.

Console notifications are **at least once**. If a process crashes after the console line but before the ack, retry can print the line again. Convex's idempotent ack/reminder mutation is the single durable activity record. This is not a claim of exactly-once external email delivery. A real notification provider would need a stable provider idempotency key, an outbox/delivery ledger, receipt reconciliation and uncertainty handling before retries.

Successful execution data is not retained. Failed execution data is saved for diagnosis and pruned after 7 days; it may include minimized loan identifiers and signed headers, so keep editor access restricted. Signatures expire after 5 minutes. No email addresses or other contact details are needed in the automation payload. Execution console log retention also needs an infrastructure policy in production.

## Wire contract

Both directions use POST, JSON and these headers:

- `x-lendloop-timestamp`: epoch seconds as a 10 digit decimal string.
- `x-lendloop-signature`: lowercase hex HMAC-SHA256 over `timestamp + '.' + exactRawBody`.
- Maximum permitted clock skew: 300 seconds. Both services require a shared secret of at least 32 characters.

Outbound event fields: `{version:1,eventId,loanId,kind,toolName,recipientUserId,status,createdAt}`. Allowed kinds are `request.created`, `request.approved`, `request.declined`, `request.returned` and `request.cancelled`; statuses are `pending`, `approved`, `declined`, `returned` and `cancelled`. `createdAt` is a finite numeric timestamp. IDs are opaque bounded strings. A valid signed event still needs to reference an existing authoritative outbox event at acknowledgement time.

Convex HTTP endpoints:

| Endpoint | Request | Success |
|---|---|---|
| `/automation/ack` | `{version:1,eventId,outcome:'logged'}` | `{ok:true,duplicate:boolean}` |
| `/automation/overdue` | `{version:1,requestId,limit:50}` | `{loans:[{loanId,toolName,borrowerId,endDate,reminderKey}],more:boolean}` |
| `/automation/reminders` | `{version:1,loanId,reminderKey,outcome:'logged'}` | `{ok:true,duplicate:boolean}` |

`endDate` is YYYY-MM-DD and strictly before today's UTC date. No secret appears in exported workflow JSON: it references environment values only. The HTTP Request nodes send the exact signed `rawBody` with raw JSON content type.

## Validation

```sh
node n8n/build-workflows.mjs
node --test n8n/test/workflows.test.mjs
```

These tests execute the actual Code-node sources and validate the exported graph. They cover valid and tampered raw-byte signatures, stale/future timestamps, invalid payloads, data minimization, confirmation-before-success, bounded pagination and failure propagation. One local HTTP fixture proves the signed wire bytes and repeated stable eventID produce one fixture record. That test is **not** a deployed Convex or n8n-engine integration test.

`smoke.mjs` is an explicit opt-in network probe. Give it an event from your controlled Convex fixture, a displayed n8n test/production webhook URL and `--send`. It prints only a sanitized result and makes one request; a timeout is not proof of failure or permission to generate a new event. Inspect the exact eventID in both systems before reusing that same event.

```sh
node n8n/smoke.mjs --send --event-file controlled-event.json --url http://localhost:5678/webhook-test/lendloop/requests
```

The host used to produce this submission has no Docker CLI. These exports have not been imported into or executed by a live n8n container here. Docker startup, owner setup, webhook raw-binary handling in the pinned engine, workflow import IDs, schedule activation, deployed Convex roundtrips and crash/restart recovery still require the controlled integration run above. No real message provider has been configured or exercised.

## Official references checked

- [Webhook, Raw Body and test/production URLs](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook/)
- [Binary buffer access in Code](https://github.com/n8n-io/n8n-docs/blob/main/docs/build/code-in-n8n/cookbook/code-node/get-the-binary-data-buffer.md)
- [Environment access and security settings](https://docs.n8n.io/hosting/configuration/environment-variables/security/)
- [Code built-in module allowlist](https://docs.n8n.io/hosting/configuration/environment-variables/nodes/)
- [Error workflows](https://docs.n8n.io/flow-logic/error-handling/)
- [Official CLI import commands](https://docs.n8n.io/hosting/cli-commands/)

Implementation was AI-assisted, as explicitly permitted by the take-home instructions. These are new exercise artifacts, not claims about the applicant's past work experience.
