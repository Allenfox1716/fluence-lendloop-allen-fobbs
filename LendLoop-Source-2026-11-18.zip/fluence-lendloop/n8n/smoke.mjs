#!/usr/bin/env node
// Explicitly opted-in smoke probe; never runs as part of tests or application submission.
import { readFileSync } from 'node:fs';
import { createHmac } from 'node:crypto';
const args = process.argv.slice(2);
function option(name) { const i = args.indexOf(name); return i < 0 ? undefined : args[i + 1]; }
if (!args.includes('--send') || !option('--event-file') || !option('--url')) {
  console.error('Usage: AUTOMATION_SHARED_SECRET=... node n8n/smoke.mjs --send --event-file controlled-event.json --url http://localhost:5678/webhook-test/lendloop/requests');
  console.error('Use a real controlled fixture event created by your Convex test deployment. This probe does not create a loan or event.');
  process.exit(2);
}
const secret = process.env.AUTOMATION_SHARED_SECRET;
if (!secret || secret.length < 32) throw new Error('Missing automation secret');
const url = new URL(option('--url'));
const local = ['localhost', '127.0.0.1'].includes(url.hostname);
if (url.username || url.password || url.hash || url.search || (url.protocol !== 'https:' && !(local && url.protocol === 'http:'))) throw new Error('Expected HTTPS or loopback webhook URL');
if (!local && !args.includes('--allow-remote')) throw new Error('Remote probe requires explicit --allow-remote');
const event = JSON.parse(readFileSync(option('--event-file'), 'utf8'));
if (event.version !== 1 || typeof event.eventId !== 'string' || typeof event.loanId !== 'string') throw new Error('Expected a controlled version1 event');
const rawBody = JSON.stringify(event);
const timestamp = String(Math.floor(Date.now() / 1000));
const signature = createHmac('sha256', secret).update(timestamp + '.' + rawBody).digest('hex');
try {
  const response = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', 'x-lendloop-timestamp': timestamp, 'x-lendloop-signature': signature }, body: rawBody, signal: AbortSignal.timeout(15000), redirect: 'error' });
  const text = await response.text();
  let result; try { result = JSON.parse(text); } catch { throw new Error(`Webhook HTTP${response.status}: response is not confirmation JSON`); }
  if (!response.ok || result.ok !== true || result.eventId !== event.eventId || result.notificationMode !== 'logged_mock') throw new Error(`Webhook HTTP${response.status}: durable logged-mock acknowledgement not confirmed`);
  console.log(JSON.stringify({ status: response.status, eventId: result.eventId, mode: result.notificationMode, duplicate: result.duplicate }));
} catch (error) {
  console.error('Probe did not establish completion. Inspect the exact eventId in Convex and the saved n8n execution before retrying the SAME event; do not create another event to hide an unknown outcome.');
  console.error(error instanceof Error ? error.name : 'Unknown error');
  process.exitCode = 1;
}
