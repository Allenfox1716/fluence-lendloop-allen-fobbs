// LendLoop isolated exercise source.
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
const AsyncFunction = Object.getPrototypeOf(async function() {}).constructor;
export const testSecret = 'test-fixture-only-32-byte-random-secret-value';
export const load = (name) => JSON.parse(readFileSync(join(root, `workflows/${name}.json`), 'utf8'));
export async function run(source, { items = [], env = {}, nodes = {}, raw = Buffer.alloc(0), runIndex = 0 } = {}) {
  const logs = [];
  const body = (source === 'sanitized-error' ? '' : readFileSync(join(root, 'code/shared.js'), 'utf8') + '\n') + readFileSync(join(root, `code/${source}.js`), 'utf8');
  const fn = new AsyncFunction('require', '$env', '$input', '$', '$runIndex', 'console', 'Buffer', body);
  const data = await fn.call({ helpers: { async getBinaryDataBuffer(index, name) { if (index !== 0 || name !== 'data') throw new Error('Wrong binary field'); return raw; } } }, require,
    { AUTOMATION_SHARED_SECRET: testSecret, CONVEX_SITE_URL: 'https://fixture.convex.site', ...env },
    { first: () => items[0] || { json: {} }, all: () => items },
    (name) => ({ first(branch, index) { return { json: typeof nodes[name] === 'function' ? nodes[name](branch, index) : nodes[name] }; } }),
    runIndex, { log: (s) => logs.push(s), error: (s) => logs.push(s) }, Buffer);
  return { data, logs };
}
