// LendLoop isolated exercise source.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { load, run, testSecret } from './harness.mjs';

const event = { version: 1, eventId: 'event1', loanId: 'loan1', kind: 'request.created', toolName: 'Drill', recipientUserId: 'user1', status: 'pending', createdAt: Date.now() };
function input(body = event, { timestamp = String(Math.floor(Date.now() / 1000)), secret = testSecret, signature, raw } = {}) {
  const bytes = raw || Buffer.from(JSON.stringify(body));
  const sig = signature || createHmac('sha256', secret).update(timestamp + '.').update(bytes).digest('hex');
  return { items: [{ json: { headers: { 'x-lendloop-timestamp': timestamp, 'x-lendloop-signature': sig }, body }, binary: { data: { data: bytes.toString('base64') } } }], raw: bytes };
}
test('valid signature verifies exact raw bytes and strips unknown data and headers', async () => {
  const result = await run('verify-event', input({ ...event, email: 'do-not-forward@example.test' }));
  assert.deepEqual(result.data, [{ json: event }]);
  assert.equal(result.logs.length, 0);
});
test('semantically identical JSON with different bytes fails verification', async () => {
  const req = input(); req.raw = Buffer.from(JSON.stringify(event, null, 2));
  await assert.rejects(run('verify-event', req), /Invalid automation authentication/);
});
test('parsed JSON cannot replace a missing raw binary body', async () => {
  const req = input(); delete req.items[0].binary;
  await assert.rejects(run('verify-event', req), /Raw webhook body/);
});
test('wrong secret, malformed signature, old and far-future timestamps fail closed', async () => {
  for (const options of [{ secret: 'wrong-secret' }, { signature: 'invalid' }, { timestamp: String(Math.floor(Date.now() / 1000) - 301) }, { timestamp: String(Math.floor(Date.now() / 1000) + 301) }]) {
    await assert.rejects(run('verify-event', input(event, options)), /automation authentication/);
  }
});
test('invalid event versions, kinds and statuses are rejected after authenticating', async () => {
  for (const body of [{ ...event, version: 2 }, { ...event, kind: 'admin.grant' }, { ...event, status: 'unknown' }, { ...event, loanId: '' }]) await assert.rejects(run('verify-event', input(body)), /Invalid automation event/);
});
test('valid but oversized payload is rejected without logging its contents', async () => {
  await assert.rejects(run('verify-event', input({ ...event, extra: 'x'.repeat(17000) })), /too large/);
});
test('request log is explicitly a mock and ack body is minimal and signed', async () => {
  const { data, logs } = await run('log-request-and-sign-ack', { items: [{ json: event }] });
  assert.equal(logs.length, 1); assert.match(logs[0], /logged_mock/);
  const req = data[0].json;
  assert.equal(req.url, 'https://fixture.convex.site/automation/ack');
  assert.deepEqual(JSON.parse(req.rawBody), { version: 1, eventId: 'event1', outcome: 'logged' });
  assert.equal(req.signature, createHmac('sha256', testSecret).update(req.timestamp + '.' + req.rawBody).digest('hex'));
  assert.equal(req.rawBody.includes(testSecret), false);
});
test('HTTP endpoints reject insecure non-local, credentialed and path-bearing base URLs', async () => {
  for (const url of ['http://public.example.test', 'https://user:password@example.test', 'https://fixture.convex.site/path', 'https://fixture.convex.site?key=bad']) await assert.rejects(run('sign-overdue-query', { env: { CONVEX_SITE_URL: url } }), /base URL/);
  await assert.rejects(run('sign-overdue-query', { env: { AUTOMATION_SHARED_SECRET: 'short' } }), /secret/);
});
const today = () => new Date().toISOString().slice(0, 10);
const yesterday = () => new Date(Date.now() - 86400000).toISOString().slice(0, 10);
const loan = () => ({ loanId: 'loan1', borrowerId: 'user1', toolName: 'Drill', endDate: yesterday(), reminderKey: 'loan1:' + today() });
const batchOptions = (result) => ({ items: [{ json: result }], nodes: { 'Sign overdue query': { runId: 'run1', batchNo: 0 } } });
test('overdue validator preserves only minimized fields and ties reminder key to UTC day', async () => {
  const result = await run('validate-overdue-batch', batchOptions({ loans: [{ ...loan(), email: 'private@example.test' }], more: false }));
  assert.deepEqual(result.data[0].json, { loans: [loan()], more: false, count: 1, runId: 'run1', batchNo: 0 });
});
test('overdue validator rejects empty-progress loops, duplicate loans, wrong day and nonoverdue items', async () => {
  for (const body of [{ loans: [], more: true }, { loans: [loan(), loan()], more: false }, { loans: [{ ...loan(), reminderKey: 'loan1:2000-01-01' }], more: false }, { loans: [{ ...loan(), endDate: today() }], more: false }]) await assert.rejects(run('validate-overdue-batch', batchOptions(body)));
});
test('reminder logs are mock and write-back payloads use the stable key', async () => {
  const result = await run('log-reminders-and-sign', { items: [{ json: { loans: [loan()] } }] });
  assert.match(result.logs[0], /logged_mock/);
  assert.deepEqual(JSON.parse(result.data[0].json.rawBody), { version: 1, loanId: 'loan1', reminderKey: loan().reminderKey, outcome: 'logged' });
});
test('batch cannot advance until every durable acknowledgement succeeds', async () => {
  const base = { nodes: { 'Validate overdue batch': { count: 2, runId: 'run1', batchNo: 0, more: true } } };
  await assert.rejects(run('advance-batch', { ...base, items: [{ json: { ok: true, duplicate: false } }] }), /not confirmed/);
  const result = await run('advance-batch', { ...base, items: [{ json: { ok: true, duplicate: false } }, { json: { ok: true, duplicate: true } }] });
  assert.equal(result.data[0].json.batchNo, 1); assert.equal(result.data[0].json.more, true);
});
test('batch loop has an explicit upper bound and unique per-page request IDs', async () => {
  const a = await run('sign-overdue-query', { items: [{ json: { runId: 'r', batchNo: 0 } }] });
  const b = await run('sign-overdue-query', { items: [{ json: { runId: 'r', batchNo: 1 } }] });
  assert.notEqual(JSON.parse(a.data[0].json.rawBody).requestId, JSON.parse(b.data[0].json.rawBody).requestId);
  await assert.rejects(run('sign-overdue-query', { items: [{ json: { runId: 'r', batchNo: 20 } }] }), /batch limit/);
});
test('webhook success is returned only after an explicit durable ack', async () => {
  await assert.rejects(run('confirm-request-ack', { items: [{ json: { ok: false } }] }), /not confirmed/);
  const result = await run('confirm-request-ack', { items: [{ json: { ok: true, duplicate: true } }], nodes: { 'Verify signed event': event } });
  assert.equal(result.data[0].json.duplicate, true); assert.equal(result.data[0].json.notificationMode, 'logged_mock');
});
test('error workflow logs only operational identifiers, not original error, stack or secret', async () => {
  const result = await run('sanitized-error', { items: [{ json: { workflow: { id: 'w' }, execution: { id: 'e', lastNodeExecuted: 'Persist results', error: { message: testSecret, stack: 'private-content' } }, payload: 'private-content' } }] });
  assert.equal(result.logs.length, 1); assert.equal(result.logs[0].includes(testSecret), false); assert.equal(result.logs[0].includes('private-content'), false);
});
test('exports have complete connections, bounded HTTP retries and linked error handling', () => {
  const workflows = ['errors', 'request-notification', 'overdue-reminders'].map(load);
  const ids = new Set(workflows.map(w => w.id)); assert.equal(ids.size, 3);
  for (const w of workflows) {
    assert.equal(w.active, false); const names = new Set(w.nodes.map(n => n.name));
    for (const [from, c] of Object.entries(w.connections)) { assert.ok(names.has(from)); for (const edges of c.main) for (const edge of edges) assert.ok(names.has(edge.node)); }
    if (w.settings.errorWorkflow) assert.ok(ids.has(w.settings.errorWorkflow));
    for (const n of w.nodes.filter(n => n.type.endsWith('.httpRequest'))) { assert.equal(n.retryOnFail, true); assert.equal(n.maxTries, 3); assert.equal(n.parameters.contentType, 'raw'); assert.equal(n.parameters.body, '={{ $json.rawBody }}'); assert.equal(n.continueOnFail, undefined); }
  }
  const request = load('request-notification'); assert.equal(request.nodes[0].parameters.options.rawBody, true); assert.equal(request.nodes[0].parameters.responseMode, 'responseNode');
});
test('signed wire request reaches a local fixture and replay has one durable fixture record', async () => {
  const entries = new Set();
  const server = createServer(async (req, res) => {
    const chunks = []; for await (const chunk of req) chunks.push(chunk); const raw = Buffer.concat(chunks);
    const signature = createHmac('sha256', testSecret).update(String(req.headers['x-lendloop-timestamp']) + '.').update(raw).digest('hex');
    if (signature !== req.headers['x-lendloop-signature']) { res.writeHead(401).end(); return; }
    const body = JSON.parse(raw.toString('utf8')); const duplicate = entries.has(body.eventId); entries.add(body.eventId);
    res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ ok: true, duplicate }));
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  try {
    const port = server.address().port;
    const { data } = await run('log-request-and-sign-ack', { items: [{ json: event }], env: { CONVEX_SITE_URL: `http://127.0.0.1:${port}`, AUTOMATION_ALLOW_LOCAL_HTTP: 'true' } });
    const r = data[0].json; const options = { method: 'POST', body: r.rawBody, headers: { 'content-type': 'application/json', 'x-lendloop-timestamp': r.timestamp, 'x-lendloop-signature': r.signature } };
    assert.deepEqual(await (await fetch(r.url, options)).json(), { ok: true, duplicate: false });
    assert.deepEqual(await (await fetch(r.url, options)).json(), { ok: true, duplicate: true }); assert.equal(entries.size, 1);
  } finally { server.close(); await once(server, 'close'); }
});
