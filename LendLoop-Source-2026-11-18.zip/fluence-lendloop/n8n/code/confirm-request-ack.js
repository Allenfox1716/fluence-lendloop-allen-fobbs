// LendLoop isolated exercise source.
const acknowledgement = $input.first().json;
if (!record(acknowledgement) || acknowledgement.ok !== true || typeof acknowledgement.duplicate !== 'boolean') throw new Error('Convex notification acknowledgement was not confirmed');
const event = $('Verify signed event').first().json;
return [{ json: { ok: true, eventId: event.eventId, notificationMode: 'logged_mock', duplicate: acknowledgement.duplicate } }];

