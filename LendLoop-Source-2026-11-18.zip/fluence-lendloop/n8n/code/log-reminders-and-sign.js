// LendLoop isolated exercise source.
const batch = $input.first().json;
return batch.loans.map((loan) => {
  console.log(JSON.stringify({ event: 'lendloop.reminder.logged_mock', loanId: loan.loanId, borrowerId: loan.borrowerId, toolName: loan.toolName, endDate: loan.endDate, reminderKey: loan.reminderKey }));
  return { json: signed('/automation/reminders', { version: 1, loanId: loan.loanId, reminderKey: loan.reminderKey, outcome: 'logged' }) };
});

