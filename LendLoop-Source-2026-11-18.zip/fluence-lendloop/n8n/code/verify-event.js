// LendLoop isolated exercise source.
// Require Webhook > Raw Body. Never reconstruct signed bytes from parsed JSON.
const input = $input.first();
const headers = input.json.headers || {};
const timestamp = headers['x-lendloop-timestamp'];
const signature = headers['x-lendloop-signature'];
if (!/^[0-9]{10}$/.test(timestamp || '') || !/^[a-f0-9]{64}$/.test(signature || '')) throw new Error('Invalid automation authentication');
if (Math.abs(Math.floor(Date.now() / 1000) - Number(timestamp)) > 300) throw new Error('Expired automation authentication');
if (!input.binary?.data) throw new Error('Raw webhook body is required');
const raw = await this.helpers.getBinaryDataBuffer(0, 'data');
if (raw.length > 16384) throw new Error('Automation payload is too large');
const expected = createHmac('sha256', secret()).update(timestamp + '.').update(raw).digest();
if (!timingSafeEqual(expected, Buffer.from(signature, 'hex'))) throw new Error('Invalid automation authentication');
let event;
try { event = JSON.parse(raw.toString('utf8')); } catch { throw new Error('Invalid automation JSON'); }
const kinds = new Set(['request.created', 'request.approved', 'request.declined', 'request.returned', 'request.cancelled']);
const statuses = new Set(['pending', 'approved', 'declined', 'returned', 'cancelled']);
if (!record(event) || event.version !== 1 || !text(event.eventId) || !text(event.loanId) || !text(event.recipientUserId) || !text(event.toolName, 100) || !kinds.has(event.kind) || !statuses.has(event.status) || !Number.isFinite(event.createdAt)) throw new Error('Invalid automation event');
// Drop inbound headers, raw bytes, and unknown fields before later nodes/logging.
return [{ json: { version: 1, eventId: event.eventId, loanId: event.loanId, kind: event.kind, toolName: event.toolName, recipientUserId: event.recipientUserId, status: event.status, createdAt: event.createdAt } }];

