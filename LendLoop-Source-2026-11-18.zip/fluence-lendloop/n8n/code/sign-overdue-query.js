// LendLoop isolated exercise source.
const prior = $input.first().json;
const batchNo = Number.isInteger(prior.batchNo) ? prior.batchNo : 0;
const runId = text(prior.runId) ? prior.runId : randomUUID();
if (batchNo < 0 || batchNo >= 20) throw new Error('Daily reminder batch limit reached; inspect remaining backlog and run again');
return [{ json: { ...signed('/automation/overdue', { version: 1, requestId: runId + ':' + batchNo, limit: 50 }), runId, batchNo } }];

