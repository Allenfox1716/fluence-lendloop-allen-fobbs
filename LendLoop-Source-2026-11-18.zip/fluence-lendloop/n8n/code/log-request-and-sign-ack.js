// LendLoop isolated exercise source.
const event = $input.first().json;
// Deliberate logged mock channel; this is not email/SMS delivery.
console.log(JSON.stringify({ event: 'lendloop.notification.logged_mock', eventId: event.eventId, loanId: event.loanId, recipientUserId: event.recipientUserId, kind: event.kind, status: event.status, toolName: event.toolName }));
const request = signed('/automation/ack', { version: 1, eventId: event.eventId, outcome: 'logged' });
return [{ json: request }];

