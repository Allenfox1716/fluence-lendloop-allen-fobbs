// Embedded into the exported Code nodes by build-workflows.mjs.
const { createHmac, timingSafeEqual, randomUUID } = require('crypto');
function secret() {
  const value = $env.AUTOMATION_SHARED_SECRET;
  if (typeof value !== 'string' || value.length < 32) throw new Error('Automation secret is not configured');
  return value;
}
function record(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }
function text(value, max = 200) { return typeof value === 'string' && value.length > 0 && value.length <= max; }
function apiBase() {
  const value = $env.CONVEX_SITE_URL;
  if (typeof value !== 'string') throw new Error('Convex HTTP base URL is not configured');
  if (/^https:\/\/[a-zA-Z0-9.-]+(?::[0-9]{1,5})?\/?$/.test(value)) return value.replace(/\/$/, '');
  if ($env.AUTOMATION_ALLOW_LOCAL_HTTP === 'true' && /^http:\/\/(?:localhost|127\.0\.0\.1|host\.docker\.internal)(?::[0-9]{1,5})?\/?$/.test(value)) return value.replace(/\/$/, '');
  throw new Error('Valid HTTPS Convex HTTP base URL required');
}
function signed(path, payload) {
  const rawBody = JSON.stringify(payload);
  const timestamp = String(Math.floor(Date.now() / 1000));
  const signature = createHmac('sha256', secret()).update(timestamp + '.').update(rawBody).digest('hex');
  return { url: apiBase() + path, rawBody, timestamp, signature };
}

