// LendLoop isolated exercise source.
const data = $input.first().json;
// Never log stack traces, original payloads, headers, environment, or arbitrary error messages.
const failure = { event: 'lendloop.automation.failed', workflowId: String(data.workflow?.id || 'unknown').slice(0, 100), executionId: String(data.execution?.id || 'unknown').slice(0, 100), failedNode: String(data.execution?.lastNodeExecuted || 'trigger').slice(0, 100), at: new Date().toISOString(), action: 'Inspect saved failed execution in restricted n8n editor; retry only after correction. Convex write-backs are idempotent.' };
console.error(JSON.stringify(failure));
return [{ json: failure }];
