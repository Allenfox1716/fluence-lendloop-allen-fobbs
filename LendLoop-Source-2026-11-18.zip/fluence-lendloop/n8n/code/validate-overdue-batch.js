// LendLoop isolated exercise source.
const result = $input.first().json;
const context = $('Sign overdue query').first(0, $runIndex).json;
if (!record(result) || !Array.isArray(result.loans) || result.loans.length > 50 || typeof result.more !== 'boolean') throw new Error('Invalid overdue-loan response');
if (result.more && result.loans.length === 0) throw new Error('Overdue response indicated more results without progress');
const today = new Date().toISOString().slice(0, 10);
const ids = new Set();
for (const loan of result.loans) {
  if (!record(loan) || !text(loan.loanId) || !text(loan.borrowerId) || !text(loan.toolName, 100) || !/^\d{4}-\d{2}-\d{2}$/.test(loan.endDate || '') || !text(loan.reminderKey, 250) || loan.reminderKey !== loan.loanId + ':' + today || ids.has(loan.loanId)) throw new Error('Invalid overdue-loan item');
  if (new Date(loan.endDate + 'T00:00:00Z').toISOString().slice(0, 10) !== loan.endDate || loan.endDate >= today) throw new Error('Loan is not overdue');
  ids.add(loan.loanId);
}
// Keep only the fields used by notification and idempotent write-back.
return [{ json: { loans: result.loans.map(({ loanId, toolName, borrowerId, endDate, reminderKey }) => ({ loanId, toolName, borrowerId, endDate, reminderKey })), more: result.more, count: result.loans.length, runId: context.runId, batchNo: context.batchNo } }];

