// LendLoop isolated exercise source.
const acknowledgements = $input.all();
const batch = $('Validate overdue batch').first(0, $runIndex).json;
if (acknowledgements.length !== batch.count || acknowledgements.some(({ json }) => !record(json) || json.ok !== true || typeof json.duplicate !== 'boolean')) throw new Error('One or more reminder write-backs were not confirmed');
return [{ json: { runId: batch.runId, batchNo: batch.batchNo + 1, more: batch.more, completedBatchCount: batch.count, notificationMode: 'logged_mock' } }];

