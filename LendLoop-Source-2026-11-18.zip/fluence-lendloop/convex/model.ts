// Typed wrappers derived directly from the schema. Convex's generated API is not
// checked in or faked; these exports use the SDK's supported generic builders.
import { queryGeneric, mutationGeneric, internalQueryGeneric, internalMutationGeneric, internalActionGeneric, httpActionGeneric } from "convex/server";
import type { QueryBuilder, MutationBuilder, ActionBuilder, HttpActionBuilder, DataModelFromSchemaDefinition, DocumentByName, TableNamesInDataModel, GenericQueryCtx, GenericMutationCtx } from "convex/server";
import type { GenericId } from "convex/values";
import schema from "./schema";
export type DataModel = DataModelFromSchemaDefinition<typeof schema>;
export type Table = TableNamesInDataModel<DataModel>;
export type Doc<T extends Table> = DocumentByName<DataModel, T>;
export type Id<T extends Table> = GenericId<T>;
export type QueryCtx = GenericQueryCtx<DataModel>;
export type MutationCtx = GenericMutationCtx<DataModel>;
export const query: QueryBuilder<DataModel, "public"> = queryGeneric;
export const mutation: MutationBuilder<DataModel, "public"> = mutationGeneric;
export const internalQuery: QueryBuilder<DataModel, "internal"> = internalQueryGeneric;
export const internalMutation: MutationBuilder<DataModel, "internal"> = internalMutationGeneric;
export const internalAction: ActionBuilder<DataModel, "internal"> = internalActionGeneric;
export const httpAction: HttpActionBuilder = httpActionGeneric;
