import { makeFunctionReference } from "convex/server";
import type { FunctionReference, FunctionType, DefaultFunctionArgs } from "convex/server";
import type { Doc, Id } from "./model";
export function internalRef<T extends FunctionType, A extends DefaultFunctionArgs, R>(name: string) {
  // Visibility is enforced by the registered internal function on the server;
  // this assertion only supplies type information for SDK-created references.
  return makeFunctionReference<T, A, R>(name) as unknown as FunctionReference<T, "internal", A, R>;
}
export const refs = {
  deliver: internalRef<"action", { eventId: Id<"outbox"> }, null>("automation:deliver"),
  recover: internalRef<"mutation", Record<string, never>, number>("automation:recover"),
  event: internalRef<"query", { eventId: Id<"outbox"> }, Doc<"outbox"> | null>("automation:event"),
  beginAttempt: internalRef<"mutation", { eventId: Id<"outbox"> }, number>("automation:beginAttempt"),
  failedAttempt: internalRef<"mutation", { eventId: Id<"outbox">; expectedAttempt: number; exhausted: boolean }, boolean>("automation:failedAttempt"),
  ack: internalRef<"mutation", { eventId: Id<"outbox">; outcome: "logged" }, { ok: true; duplicate: boolean }>("automation:ack"),
  overdue: internalRef<"query", { limit: number }, { loans: { loanId: Id<"loans">; toolName: string; borrowerId: string; endDate: string; reminderKey: string }[]; more: boolean }>("automation:overdue"),
  reminder: internalRef<"mutation", { loanId: Id<"loans">; reminderKey: string; outcome: "logged" }, { ok: true; duplicate: boolean }>("automation:reminder"),
};
