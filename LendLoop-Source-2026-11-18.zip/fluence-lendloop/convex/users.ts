import { v, ConvexError } from "convex/values";
import { mutation, query } from "./model";
import { actor, requireAdmin } from "./access";
export const ensure = mutation({ args: {}, handler: async ctx => {
  const user = await actor(ctx);
  if (user.profile) return { role: user.role };
  const admins = (process.env.ADMIN_USER_IDS ?? "").split(",").map(x => x.trim()).filter(Boolean);
  const role = admins.includes(user.id) ? "admin" as const : "user" as const;
  await ctx.db.insert("profiles", { userId: user.id, displayName: user.displayName, role, trusted: false });
  return { role };
} });
export const me = query({ args: {}, handler: async ctx => {
  const user = await actor(ctx);return { role: user.role, displayName: user.profile?.displayName ?? user.displayName };
} });
export const setTrusted = mutation({ args: { toolId: v.id("tools"), trusted: v.boolean() }, handler: async (ctx, args) => {
  const user = await actor(ctx);requireAdmin(user);
  const tool = await ctx.db.get(args.toolId);
  if (!tool) throw new ConvexError("Listing not found.");
  const profile = await ctx.db.query("profiles").withIndex("by_user", q => q.eq("userId", tool.ownerId)).unique();
  if (!profile) throw new ConvexError("Lender profile is unavailable.");
  await ctx.db.patch(profile._id, { trusted: args.trusted });
} });
