import { v, ConvexError } from "convex/values";
import { internalQuery, internalMutation, internalAction } from "./model";
import { refs } from "./refs";
import { todayUTC } from "../src/domain/rules";
import { signBody } from "../src/domain/signatures";

export const event = internalQuery({ args: { eventId: v.id("outbox") }, handler: async (ctx, { eventId }) => await ctx.db.get(eventId) });
export const recover = internalMutation({ args: {}, handler: async ctx => {
  const pending = await ctx.db.query("outbox").withIndex("by_state_lease", q => q.eq("state", "pending")).take(100);
  const expired = await ctx.db.query("outbox").withIndex("by_state_lease", q => q.eq("state", "sending").lt("leaseUntil", Date.now())).take(100);
  let scheduled = 0;
  for (const row of [...pending, ...expired]) {
    if (row.attempts >= 5) {
      await ctx.db.patch(row._id, { state: "failed", leaseUntil: 0, lastErrorCode: "notification_retry_exhausted" });
      const key = `event-failed:${row._id}`;
      if (!await ctx.db.query("activity").withIndex("by_key", q => q.eq("key", key)).unique()) await ctx.db.insert("activity", { loanId: row.loanId, key, kind: "notification", at: Date.now(), outcome: "failed; operator review required" });
    } else {
      await ctx.db.patch(row._id, { state: "pending", leaseUntil: 0 });
      await ctx.scheduler.runAfter(0, refs.deliver, { eventId: row._id });scheduled++;
    }
  }
  return scheduled;
} });
export const beginAttempt = internalMutation({ args: { eventId: v.id("outbox") }, handler: async (ctx, { eventId }) => {
  const row = await ctx.db.get(eventId);
  if (!row || row.attempts >= 5 || row.state === "acknowledged" || row.state === "failed" || (row.state === "sending" && (row.leaseUntil ?? 0) > Date.now())) return 0;
  const attempt = row.attempts + 1;
  await ctx.db.patch(eventId, { attempts: attempt, state: "sending", leaseUntil: Date.now() + 15_000 });
  return attempt;
} });
export const failedAttempt = internalMutation({ args: { eventId: v.id("outbox"), expectedAttempt: v.number(), exhausted: v.boolean() }, handler: async (ctx, args) => {
  const row = await ctx.db.get(args.eventId);if (!row || row.state === "acknowledged" || row.state === "failed" || row.attempts !== args.expectedAttempt) return false;
  await ctx.db.patch(row._id, { state: args.exhausted ? "failed" : "pending", leaseUntil: 0, lastErrorCode: "notification_delivery_failed" });
  if (args.exhausted) {
    const key = `event-failed:${row._id}`;
    if (!await ctx.db.query("activity").withIndex("by_key", q => q.eq("key", key)).unique()) await ctx.db.insert("activity", { loanId: row.loanId, key, kind: "notification", at: Date.now(), outcome: "failed; operator review required" });
  }
  return !args.exhausted;
} });
export const ack = internalMutation({ args: { eventId: v.id("outbox"), outcome: v.literal("logged") }, handler: async (ctx, args) => {
  const row = await ctx.db.get(args.eventId);
  if (!row) throw new ConvexError("Unknown automation event.");
  const key = `event:${row._id}`;
  const prior = await ctx.db.query("activity").withIndex("by_key", q => q.eq("key", key)).unique();
  if (prior) return { ok: true as const, duplicate: true };
  await ctx.db.insert("activity", { loanId: row.loanId, key, kind: row.kind, at: Date.now(), outcome: "mock notification logged" });
  await ctx.db.patch(row._id, { state: "acknowledged", leaseUntil: 0, lastErrorCode: undefined });
  return { ok: true as const, duplicate: false };
} });
export const overdue = internalQuery({ args: { limit: v.number() }, handler: async (ctx, args) => {
  const today = todayUTC();const limit = Math.min(Math.max(Math.floor(args.limit), 1), 50);
  const rows = await ctx.db.query("loans").withIndex("by_status_end", q => q.eq("status", "approved").lt("endDate", today)).take(1001);
  if (rows.length > 1000) throw new ConvexError("Overdue backlog exceeds the exercise safety limit; operator review is required.");
  const result = [];
  for (const loan of rows) {
    const reminderKey = `${loan._id}:${today}`;
    if (await ctx.db.query("activity").withIndex("by_key", q => q.eq("key", `reminder:${reminderKey}`)).unique()) continue;
    const tool = await ctx.db.get(loan.toolId);
    result.push({ loanId: loan._id, toolName: tool?.name ?? "Removed tool", borrowerId: loan.borrowerId, endDate: loan.endDate, reminderKey });
    if (result.length > limit) break;
  }
  return { loans: result.slice(0, limit), more: result.length > limit };
} });
export const reminder = internalMutation({ args: { loanId: v.id("loans"), reminderKey: v.string(), outcome: v.literal("logged") }, handler: async (ctx, args) => {
  const key = `reminder:${args.reminderKey}`;
  if (await ctx.db.query("activity").withIndex("by_key", q => q.eq("key", key)).unique()) return { ok: true as const, duplicate: true };
  const loan = await ctx.db.get(args.loanId);const today = todayUTC();
  if (!loan || loan.status !== "approved" || loan.endDate >= today || args.reminderKey !== `${loan._id}:${today}`) throw new ConvexError("The loan is no longer eligible for this reminder.");
  await ctx.db.insert("activity", { loanId: loan._id, key, kind: "overdue reminder", at: Date.now(), outcome: "mock reminder logged" });
  return { ok: true as const, duplicate: false };
} });
export const deliver = internalAction({ args: { eventId: v.id("outbox") }, handler: async (ctx, { eventId }): Promise<null> => {
  const row = await ctx.runQuery(refs.event, { eventId });
  if (!row || row.state === "acknowledged" || row.state === "failed") return null;
  const attempt = await ctx.runMutation(refs.beginAttempt, { eventId });
  if (attempt === 0) return null;
  try {
    const secret = process.env.AUTOMATION_SHARED_SECRET ?? "";
    const url = new URL(process.env.N8N_REQUEST_WEBHOOK_URL ?? "");
    if (url.username || url.password) throw new Error("Credential-bearing automation URL is not allowed.");
    const local = process.env.ALLOW_LOCAL_AUTOMATION === "true" && ["localhost", "127.0.0.1", "host.docker.internal"].includes(url.hostname);
    if (url.protocol !== "https:" && !(local && url.protocol === "http:")) throw new Error("Unsafe automation URL.");
    const body = JSON.stringify({ version: 1, eventId, loanId: row.loanId, kind: row.kind, toolName: row.toolName, recipientUserId: row.recipientUserId, status: row.status, createdAt: row.createdAt });
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const signature = await signBody(secret, timestamp, body);
    const response = await fetch(url, { method: "POST", redirect: "error", signal: AbortSignal.timeout(8_000), headers: { "content-type": "application/json", "x-lendloop-timestamp": timestamp, "x-lendloop-signature": signature }, body });
    if (!response.ok) throw new Error("Automation HTTP failure.");
    // A generic HTTP200 is not notification acceptance: require the durable ack.
    const final = await ctx.runQuery(refs.event, { eventId });
    if (final?.state !== "acknowledged") throw new Error("Missing durable acknowledgement.");
  } catch {
    const exhausted = attempt >= 5;
    const shouldRetry = await ctx.runMutation(refs.failedAttempt, { eventId, expectedAttempt: attempt, exhausted });
    if (shouldRetry) await ctx.scheduler.runAfter(Math.min(5_000 * 2 ** (attempt - 1), 80_000), refs.deliver, { eventId });
  }
  return null;
} });
