import { ConvexError } from "convex/values";
import type { QueryCtx, MutationCtx, Doc } from "./model";
export async function actor(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError("Sign in to continue.");
  const profile = await ctx.db.query("profiles").withIndex("by_user", q => q.eq("userId", identity.subject)).unique();
  return { id: identity.subject, role: profile?.role ?? "user", profile, displayName: (identity.name ?? "Neighbor").slice(0, 80) };
}
export function requireAdmin(user: { role: string }) {
  if (user.role !== "admin") throw new ConvexError("Administrator access is required.");
}
export function requireOwner(ownerId: string, userId: string) {
  if (ownerId !== userId) throw new ConvexError("You can only change your own listings.");
}
export function requireParticipant(loan: Doc<"loans">, user: { id: string; role: string }) {
  if (loan.ownerId !== user.id && loan.borrowerId !== user.id && user.role !== "admin") throw new ConvexError("This loan is not available to you.");
}
