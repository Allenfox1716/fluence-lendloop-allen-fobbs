import { cronJobs } from "convex/server";
import { refs } from "./refs";
const crons = cronJobs();
crons.interval("recover interrupted notification deliveries", { minutes: 5 }, refs.recover, {});
export default crons;
