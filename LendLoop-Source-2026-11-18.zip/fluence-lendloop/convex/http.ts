import { httpRouter } from "convex/server";
import { httpAction } from "./model";
import type { Id } from "./model";
import { refs } from "./refs";
import { MAX_BODY_BYTES, verifySignedBody } from "../src/domain/signatures";
const router = httpRouter();
function json(data: unknown, status = 200) { return new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } }); }
async function boundedBody(request: Request) {
  const reader = request.body?.getReader();if (!reader) throw new Error("Missing body.");
  const chunks: Uint8Array[] = [];let size = 0;
  while (true) { const { value, done } = await reader.read();if (done) break;size += value.byteLength;if (size > MAX_BODY_BYTES) { await reader.cancel();throw new Error("Too large."); }chunks.push(value); }
  const result = new Uint8Array(size);let offset = 0;for (const c of chunks) { result.set(c, offset);offset += c.length; }
  return new TextDecoder("utf-8", { fatal: true }).decode(result);
}
const handler = httpAction(async (ctx, request) => {
  const secret = process.env.AUTOMATION_SHARED_SECRET ?? "";
  if (secret.length < 32) return json({ error: "automation_not_configured" }, 503);
  let raw: string;
  try { raw = await boundedBody(request); } catch { return json({ error: "invalid_body" }, 400); }
  if (!await verifySignedBody(secret, request.headers.get("x-lendloop-timestamp"), request.headers.get("x-lendloop-signature"), raw)) return json({ error: "unauthorized" }, 401);
  let body: Record<string, unknown>;
  try { const value: unknown = JSON.parse(raw);if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error();body = value as Record<string, unknown>; } catch { return json({ error: "invalid_json" }, 400); }
  if (body.version !== 1) return json({ error: "unsupported_version" }, 400);
  const path = new URL(request.url).pathname;
  try {
    if (path === "/automation/ack" && typeof body.eventId === "string" && body.eventId.length <= 200 && body.outcome === "logged") return json(await ctx.runMutation(refs.ack, { eventId: body.eventId as Id<"outbox">, outcome: "logged" }));
    if (path === "/automation/overdue" && typeof body.requestId === "string" && body.requestId.length <= 200 && Number.isInteger(body.limit) && Number(body.limit) >= 1 && Number(body.limit) <= 50) return json(await ctx.runQuery(refs.overdue, { limit: Number(body.limit) }));
    if (path === "/automation/reminders" && typeof body.loanId === "string" && body.loanId.length <= 200 && typeof body.reminderKey === "string" && body.reminderKey.length <= 250 && body.outcome === "logged") return json(await ctx.runMutation(refs.reminder, { loanId: body.loanId as Id<"loans">, reminderKey: body.reminderKey, outcome: "logged" }));
    return json({ error: "invalid_payload" }, 400);
  } catch { return json({ error: "operation_rejected" }, 409); }
});
for (const path of ["/automation/ack", "/automation/overdue", "/automation/reminders"]) router.route({ path, method: "POST", handler });
export default router;
