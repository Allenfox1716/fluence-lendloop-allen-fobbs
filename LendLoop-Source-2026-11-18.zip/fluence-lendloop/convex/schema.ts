import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
export const loanStatus = v.union(v.literal("pending"), v.literal("approved"), v.literal("declined"), v.literal("returned"), v.literal("cancelled"));
export default defineSchema({
  profiles: defineTable({ userId: v.string(), displayName: v.string(), role: v.union(v.literal("user"), v.literal("admin")), trusted: v.boolean() }).index("by_user", ["userId"]),
  tools: defineTable({ ownerId: v.string(), name: v.string(), category: v.string(), condition: v.string(), description: v.string(), removedAt: v.optional(v.number()) }).index("by_owner", ["ownerId"]),
  loans: defineTable({ toolId: v.id("tools"), ownerId: v.string(), borrowerId: v.string(), startDate: v.string(), endDate: v.string(), status: loanStatus, updatedAt: v.number() }).index("by_tool", ["toolId"]).index("by_owner", ["ownerId"]).index("by_borrower", ["borrowerId"]).index("by_status_end", ["status", "endDate"]),
  outbox: defineTable({ loanId: v.id("loans"), kind: v.string(), toolName: v.string(), recipientUserId: v.string(), status: loanStatus, createdAt: v.number(), state: v.union(v.literal("pending"), v.literal("sending"), v.literal("acknowledged"), v.literal("failed")), attempts: v.number(), leaseUntil: v.optional(v.number()), lastErrorCode: v.optional(v.string()) }).index("by_loan", ["loanId"]).index("by_state_lease", ["state", "leaseUntil"]),
  activity: defineTable({ loanId: v.id("loans"), key: v.string(), kind: v.string(), at: v.number(), outcome: v.string() }).index("by_loan", ["loanId"]).index("by_key", ["key"]),
});
