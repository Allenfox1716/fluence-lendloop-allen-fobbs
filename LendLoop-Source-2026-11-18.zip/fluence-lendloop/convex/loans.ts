import { v, ConvexError } from "convex/values";
import { query, mutation } from "./model";
import { actor, requireOwner } from "./access";
import { validateRange, overlaps, todayUTC } from "../src/domain/rules";
import { queueEvent } from "./events";
export const request = mutation({ args: { toolId: v.id("tools"), startDate: v.string(), endDate: v.string() }, handler: async (ctx, args) => {
  const user = await actor(ctx); const tool = await ctx.db.get(args.toolId);
  if (!tool || tool.removedAt) throw new ConvexError("Listing is no longer available.");
  if (tool.ownerId === user.id) throw new ConvexError("You cannot borrow your own tool.");
  validateRange(args.startDate, args.endDate);
  const loans = await ctx.db.query("loans").withIndex("by_tool", q => q.eq("toolId", tool._id)).collect();
  if (loans.some(l => l.status === "approved" && overlaps(l.startDate, l.endDate, args.startDate, args.endDate))) throw new ConvexError("An approved loan already overlaps those dates.");
  if (loans.some(l => l.borrowerId === user.id && l.status === "pending" && l.startDate === args.startDate && l.endDate === args.endDate)) throw new ConvexError("Your request for these dates already exists.");
  const id = await ctx.db.insert("loans", { toolId: tool._id, ownerId: tool.ownerId, borrowerId: user.id, startDate: args.startDate, endDate: args.endDate, status: "pending", updatedAt: Date.now() });
  const loan = (await ctx.db.get(id))!;
  await queueEvent(ctx, loan, "request.created", tool.ownerId, tool.name);
  return id;
} });
export const decide = mutation({ args: { loanId: v.id("loans"), decision: v.union(v.literal("approved"), v.literal("declined")) }, handler: async (ctx, args) => {
  const user = await actor(ctx); const loan = await ctx.db.get(args.loanId);
  if (!loan) throw new ConvexError("Request not found.");
  requireOwner(loan.ownerId, user.id);
  if (loan.status !== "pending") throw new ConvexError("This request is no longer pending.");
  const tool = await ctx.db.get(loan.toolId);
  if (!tool || tool.removedAt) throw new ConvexError("Listing is no longer available.");
  if (args.decision === "approved") {
    validateRange(loan.startDate, loan.endDate);
    const existing = await ctx.db.query("loans").withIndex("by_tool", q => q.eq("toolId", loan.toolId)).collect();
    if (existing.some(l => l._id !== loan._id && l.status === "approved" && overlaps(l.startDate, l.endDate, loan.startDate, loan.endDate))) throw new ConvexError("Another approved loan overlaps these dates.");
  }
  await ctx.db.patch(loan._id, { status: args.decision, updatedAt: Date.now() });
  await queueEvent(ctx, { ...loan, status: args.decision }, `request.${args.decision}`, loan.borrowerId, tool.name);
} });
export const markReturned = mutation({ args: { loanId: v.id("loans") }, handler: async (ctx, args) => {
  const user = await actor(ctx); const loan = await ctx.db.get(args.loanId);
  if (!loan || ![loan.ownerId, loan.borrowerId].includes(user.id)) throw new ConvexError("Only this lender or borrower can mark the return.");
  if (loan.status !== "approved") throw new ConvexError("Only an approved loan can be returned.");
  if (loan.startDate > todayUTC()) throw new ConvexError("This loan has not started yet.");
  const tool = await ctx.db.get(loan.toolId);
  await ctx.db.patch(loan._id, { status: "returned", updatedAt: Date.now() });
  await queueEvent(ctx, { ...loan, status: "returned" }, "request.returned", user.id === loan.ownerId ? loan.borrowerId : loan.ownerId, tool?.name ?? "Removed tool");
} });
export const cancel = mutation({ args: { loanId: v.id("loans") }, handler: async (ctx, args) => {
  const user = await actor(ctx); const loan = await ctx.db.get(args.loanId);
  if (!loan || loan.borrowerId !== user.id || loan.status !== "pending") throw new ConvexError("Only your pending request can be cancelled.");
  const tool = await ctx.db.get(loan.toolId);
  await ctx.db.patch(loan._id, { status: "cancelled", updatedAt: Date.now() });
  await queueEvent(ctx, { ...loan, status: "cancelled" }, "request.cancelled", loan.ownerId, tool?.name ?? "Removed tool");
} });
export const list = query({ args: { scope: v.union(v.literal("mine"), v.literal("incoming"), v.literal("all")) }, handler: async (ctx, args) => {
  const user = await actor(ctx);
  if (args.scope === "all" && user.role !== "admin") throw new ConvexError("Administrator access is required.");
  const loans = args.scope === "all" ? await ctx.db.query("loans").order("desc").take(200) : args.scope === "incoming" ? await ctx.db.query("loans").withIndex("by_owner", q => q.eq("ownerId", user.id)).order("desc").take(200) : await ctx.db.query("loans").withIndex("by_borrower", q => q.eq("borrowerId", user.id)).order("desc").take(200);
  return await Promise.all(loans.map(async loan => {
    const tool = await ctx.db.get(loan.toolId);
    const borrower = await ctx.db.query("profiles").withIndex("by_user", q => q.eq("userId", loan.borrowerId)).unique();
    const owner = await ctx.db.query("profiles").withIndex("by_user", q => q.eq("userId", loan.ownerId)).unique();
    const activity = await ctx.db.query("activity").withIndex("by_loan", q => q.eq("loanId", loan._id)).order("desc").take(8);
    return { id: loan._id, toolName: tool?.name ?? "Removed listing", startDate: loan.startDate, endDate: loan.endDate, status: loan.status, borrowerLabel: borrower?.displayName ?? "Neighbor", lenderLabel: owner?.displayName ?? "Neighbor", canDecide: loan.ownerId === user.id && loan.status === "pending", canReturn: [loan.ownerId, loan.borrowerId].includes(user.id) && loan.status === "approved" && loan.startDate <= todayUTC(), canCancel: loan.borrowerId === user.id && loan.status === "pending", activities: activity.map(a => ({ id: a._id, kind: a.kind, at: a.at, outcome: a.outcome })) };
  }));
} });
