import type { MutationCtx, Doc } from "./model";
import { refs } from "./refs";
export async function queueEvent(ctx: MutationCtx, loan: Doc<"loans">, kind: string, recipientUserId: string, toolName: string) {
  const id = await ctx.db.insert("outbox", { loanId: loan._id, kind, toolName, recipientUserId, status: loan.status, createdAt: Date.now(), state: "pending", attempts: 0 });
  await ctx.scheduler.runAfter(0, refs.deliver, { eventId: id });
  return id;
}
