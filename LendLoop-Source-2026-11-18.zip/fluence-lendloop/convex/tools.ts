import { v, ConvexError } from "convex/values";
import { query, mutation } from "./model";
import { actor, requireOwner } from "./access";
import { CATEGORIES, CONDITIONS, boundedText, todayUTC } from "../src/domain/rules";
import { queueEvent } from "./events";
const listingArgs = { name: v.string(), category: v.string(), condition: v.string(), description: v.string() };
function clean(args: { name: string; category: string; condition: string; description: string }) {
  if (!(CATEGORIES as readonly string[]).includes(args.category) || !(CONDITIONS as readonly string[]).includes(args.condition)) throw new ConvexError("Choose a supported category and condition.");
  return { name: boundedText(args.name, "Tool name", 80), category: args.category, condition: args.condition, description: boundedText(args.description, "Description", 600) };
}
export const publicList = query({ args: {}, handler: async ctx => {
  const today = todayUTC();
  const tools = await ctx.db.query("tools").order("desc").take(200);
  const out: { name: string; category: string }[] = [];
  for (const tool of tools) {
    if (tool.removedAt) continue;
    const loans = await ctx.db.query("loans").withIndex("by_tool", q => q.eq("toolId", tool._id)).collect();
    if (!loans.some(l => l.status === "approved" && l.startDate <= today)) out.push({ name: tool.name, category: tool.category });
  }
  return out;
} });
export const list = query({ args: {}, handler: async ctx => {
  const user = await actor(ctx); const today = todayUTC();
  const tools = await ctx.db.query("tools").order("desc").take(200);
  return await Promise.all(tools.filter(t => !t.removedAt || t.ownerId === user.id || user.role === "admin").map(async tool => {
    const loans = await ctx.db.query("loans").withIndex("by_tool", q => q.eq("toolId", tool._id)).collect();
    const owner = await ctx.db.query("profiles").withIndex("by_user", q => q.eq("userId", tool.ownerId)).unique();
    return { id: tool._id, name: tool.name, category: tool.category, condition: tool.condition, description: tool.description, isOwner: tool.ownerId === user.id, trusted: owner?.trusted ?? false, ownerLabel: owner?.displayName ?? "Neighbor", availability: loans.some(l => l.status === "approved" && l.startDate <= today) ? "On loan" as const : "Available" as const, removed: !!tool.removedAt };
  }));
} });
export const create = mutation({ args: listingArgs, handler: async (ctx, args) => {
  const user = await actor(ctx);
  const profile = await ctx.db.query("profiles").withIndex("by_user", q => q.eq("userId", user.id)).unique();
  if (!profile) throw new ConvexError("Finish signing in, then try again.");
  return await ctx.db.insert("tools", { ...clean(args), ownerId: user.id });
} });
export const edit = mutation({ args: { toolId: v.id("tools"), ...listingArgs }, handler: async (ctx, args) => {
  const user = await actor(ctx); const tool = await ctx.db.get(args.toolId);
  if (!tool || tool.removedAt) throw new ConvexError("Listing not found.");
  requireOwner(tool.ownerId, user.id);
  await ctx.db.patch(tool._id, clean(args));
} });
export const remove = mutation({ args: { toolId: v.id("tools") }, handler: async (ctx, args) => {
  const user = await actor(ctx); const tool = await ctx.db.get(args.toolId);
  if (!tool) throw new ConvexError("Listing not found.");
  if (user.role !== "admin") requireOwner(tool.ownerId, user.id);
  if (tool.removedAt) return;
  await ctx.db.patch(tool._id, { removedAt: Date.now() });
  const loans = await ctx.db.query("loans").withIndex("by_tool", q => q.eq("toolId", tool._id)).collect();
  for (const loan of loans.filter(l => l.status === "pending")) {
    await ctx.db.patch(loan._id, { status: "declined", updatedAt: Date.now() });
    await queueEvent(ctx, { ...loan, status: "declined" }, "request.declined", loan.borrowerId, tool.name);
  }
} });
