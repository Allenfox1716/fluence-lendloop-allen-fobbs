import type { GenericId } from "convex/values";
import type { LoanStatus } from "./rules";
export type ToolId = GenericId<"tools">;
export type LoanId = GenericId<"loans">;
export type PublicTool = { name: string; category: string };
export type ToolView = { id: ToolId; name: string; category: string; condition: string; description: string; isOwner: boolean; trusted: boolean; ownerLabel: string; availability: "Available" | "On loan"; removed: boolean };
export type ActivityView = { id: string; kind: string; at: number; outcome: string };
export type LoanView = { id: LoanId; toolName: string; startDate: string; endDate: string; status: LoanStatus; borrowerLabel: string; lenderLabel: string; canDecide: boolean; canReturn: boolean; canCancel: boolean; activities: ActivityView[] };
export type LoanScope = "mine" | "incoming" | "all";
