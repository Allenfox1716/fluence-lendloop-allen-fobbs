export const CATEGORIES = ["Power tools", "Garden", "Kitchen", "Camping", "Hand tools", "Other"] as const;
export const CONDITIONS = ["Like new", "Good", "Fair"] as const;
export type Category = typeof CATEGORIES[number];
export type Condition = typeof CONDITIONS[number];
export type LoanStatus = "pending" | "approved" | "declined" | "returned" | "cancelled";
export function todayUTC(now = Date.now()): string { return new Date(now).toISOString().slice(0, 10); }
export function validDate(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value + "T00:00:00Z")) && new Date(value + "T00:00:00Z").toISOString().slice(0, 10) === value;
}
export function validateRange(start: string, end: string, today = todayUTC()): void {
  if (!validDate(start) || !validDate(end) || end < start) throw new Error("Choose a valid start and end date.");
  if (start < today) throw new Error("The start date cannot be in the past.");
  const days = (Date.parse(end) - Date.parse(start)) / 86_400_000;
  if (days > 365) throw new Error("Choose a date range of at most one year.");
}
export function overlaps(aStart: string, aEnd: string, bStart: string, bEnd: string): boolean {
  return aStart <= bEnd && bStart <= aEnd;
}
export function boundedText(value: string, label: string, max: number): string {
  const clean = value.trim();
  if (!clean || clean.length > max) throw new Error(`${label} must contain 1–${max} characters.`);
  return clean;
}
