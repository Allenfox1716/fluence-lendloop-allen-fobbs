const encoder = new TextEncoder();
export const MAX_BODY_BYTES = 16_384;
function secretBytes(secret: string) {
  if (secret.length < 32) throw new Error("Automation secret is not configured.");
  return encoder.encode(secret);
}
export async function signBody(secret: string, timestamp: string, rawBody: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", secretBytes(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const result = await crypto.subtle.sign("HMAC", key, encoder.encode(`${timestamp}.${rawBody}`));
  return Array.from(new Uint8Array(result), b => b.toString(16).padStart(2, "0")).join("");
}
export async function verifySignedBody(secret: string, timestamp: string | null, signature: string | null, body: string, now = Date.now()): Promise<boolean> {
  if (!timestamp || !signature || !/^\d{10}$/.test(timestamp) || !/^[a-f0-9]{64}$/.test(signature)) return false;
  if (encoder.encode(body).byteLength > MAX_BODY_BYTES || Math.abs(now / 1000 - Number(timestamp)) > 300) return false;
  const expected = await signBody(secret, timestamp, body);
  let mismatch = 0;
  for (let i = 0; i < 64; i++) mismatch |= expected.charCodeAt(i) ^ signature.charCodeAt(i);
  return mismatch === 0;
}
