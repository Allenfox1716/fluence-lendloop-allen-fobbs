import { clerkMiddleware } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";
// This page has a deliberately public read-only catalog. Private access is
// enforced in every Convex function, never by client visibility alone.
export default process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY ? clerkMiddleware() : () => NextResponse.next();
export const config = { matcher: ["/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico)).*)", "/(api|trpc)(.*)"] };
