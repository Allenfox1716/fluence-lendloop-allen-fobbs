import { makeFunctionReference } from "convex/server";
import type { PublicTool, ToolView, LoanView, LoanScope, ToolId, LoanId } from "../domain/views";
import type { Category, Condition } from "../domain/rules";
type Empty = Record<string, never>;
export type ListingInput = { name: string; category: Category; condition: Condition; description: string };
export const api = {
  users: {
    ensure: makeFunctionReference<"mutation", Empty, { role: "admin" | "user" }>("users:ensure"),
    me: makeFunctionReference<"query", Empty, { role: string; displayName: string }>("users:me"),
    setTrusted: makeFunctionReference<"mutation", { toolId: ToolId; trusted: boolean }, null>("users:setTrusted"),
  },
  tools: {
    publicList: makeFunctionReference<"query", Empty, PublicTool[]>("tools:publicList"),
    list: makeFunctionReference<"query", Empty, ToolView[]>("tools:list"),
    create: makeFunctionReference<"mutation", ListingInput, ToolId>("tools:create"),
    edit: makeFunctionReference<"mutation", ListingInput & { toolId: ToolId }, null>("tools:edit"),
    remove: makeFunctionReference<"mutation", { toolId: ToolId }, null>("tools:remove"),
  },
  loans: {
    list: makeFunctionReference<"query", { scope: LoanScope }, LoanView[]>("loans:list"),
    request: makeFunctionReference<"mutation", { toolId: ToolId; startDate: string; endDate: string }, LoanId>("loans:request"),
    decide: makeFunctionReference<"mutation", { loanId: LoanId; decision: "approved" | "declined" }, null>("loans:decide"),
    markReturned: makeFunctionReference<"mutation", { loanId: LoanId }, null>("loans:markReturned"),
    cancel: makeFunctionReference<"mutation", { loanId: LoanId }, null>("loans:cancel"),
  },
};
