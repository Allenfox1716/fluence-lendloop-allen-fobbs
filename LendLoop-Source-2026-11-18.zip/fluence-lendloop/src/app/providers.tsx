"use client";
import { ClerkProvider, useAuth } from "@clerk/nextjs";
import { ConvexProviderWithClerk } from "convex/react-clerk";
import { ConvexReactClient } from "convex/react";
import { createContext, useContext } from "react";
const key = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;
const url = process.env.NEXT_PUBLIC_CONVEX_URL;
const convex = url ? new ConvexReactClient(url) : null;
const Configured = createContext(false);
export function useConfigured() { return useContext(Configured); }
export function Providers({ children }: { children: React.ReactNode }) {
  if (!key || !convex) return <Configured.Provider value={false}>{children}</Configured.Provider>;
  return <Configured.Provider value={true}><ClerkProvider publishableKey={key}><ConvexProviderWithClerk client={convex} useAuth={useAuth}>{children}</ConvexProviderWithClerk></ClerkProvider></Configured.Provider>;
}
